<?php
$koneksi=mysql_connect("localhost","root","") or die ("Koneksi Gagal");
mysql_select_db("lennyshop");
?>