<?php
include"../../koneksi/koneksi.php";
$awal=date("Y-m-d", strtotime($_GET['a']));
$akhir=date("Y-m-d", strtotime($_GET['b']));
?>

<table width="98%" border="0" align="center">
  <tr>
    <td class="tdat"><h2>Laporan Barang Terjual</h2></td>
  </tr>
</table><br />
<table width="98%" border="0" align="center" class="tabel2">
    <tr height="30">
    	<td align="center" width="3%"><strong>No</strong></td>
        <td align="center" width="5%"><strong>Tanggal</strong></td>
        <td align="center" width="10%"><strong>No Transaksi</strong></td>
        <td align="center" width="20%"><strong>Nama Barang</strong></td>
        <td align="center" width="10%"><strong>Jumlah</strong></td>
        <td align="center" width="10%"><strong>Total Bayar</strong></td>
    </tr>
    <?php
	$querycount="select * from pesanan where status='Lunas' and tgl_order >= '$awal' and tgl_order <= '$akhir' order by tgl_order desc";
	$sql=mysql_query($querycount);
	while($dt=mysql_fetch_array($sql)){
		$notrans=$dt['no_trans'];
		$query = "SELECT * FROM detail_pesanan where no_trans='$notrans' and tgl_order >= '$awal' and tgl_order <= '$akhir' ";			
		$result = mysql_query($query) or die('Error');
		$i = 1;
		while($row=mysql_fetch_array($result)){
			$kode=$row['id_produk'];
			$sql1=mysql_query("select * from produk where id_produk=$kode");
			$rs2=mysql_fetch_array($sql1);
			$tgl=$row['tgl_order'];
			$tgl2 = date("d-m-Y", strtotime($tgl));
			$sttl=$rs2['harga_produk']*$row['jumbel'];
	?>
    <tr height="30">
		<td align="center">&nbsp;<?=$c=$c+1;?></td>
        <td align="center">&nbsp;<?=$tgl2; ?></td>
        <td align="center">&nbsp;<?=$row['no_trans']; ?></td>
        <td>&nbsp;<?=$rs2['nama_produk']; ?></td>
        <td align="center">&nbsp;<?=$row['jumbel']; ?></td>
        <td align="center">&nbsp;Rp. <?=$sttl;?>,-</td>
    </tr>
	<?php
   	$i++;
	$ttl=$sttl+$ttl;
	} } ?>
    <tr height="30">
      	<td colspan="5" align="center"><strong>TOTAL PENDAPATAN</strong></td>
      	<td align="center">&nbsp;Rp. <?=$ttl;?>,-</td>
    </tr>
</table>