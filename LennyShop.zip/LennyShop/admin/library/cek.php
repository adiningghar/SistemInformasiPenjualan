<?php
echo $_POST['tgl_awal'];
?>