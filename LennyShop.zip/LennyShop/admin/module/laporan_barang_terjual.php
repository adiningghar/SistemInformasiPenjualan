<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<style type="text/css">
#perperiode .tabel2 tr td strong {
	color: #636363;
	font-size: 12px;
	font-family: Arial, Helvetica, sans-serif;
}
.table-periode {
	color: #636363;
	font-family: Arial, Helvetica, sans-serif;
}
#perperiode table tr .tdat h2 {
	font-family: Harrington;
}
</style>
</head>

<body>

<table width="98%" border="0" align="center">
  <tr>
    <td><h2 class="table-periode">Pilih Periode</h2></td>
  </tr>
  <tr>
    <td><form><input type="date" name="tgl_awal" id="tgl_awal"> sampai dengan <input type="date" name="tgl_akhir" id="tgl_akhir"> || <a href="?page=laporan_barang_terjual" class="ahref">Lihat Keseluruhan</a></form></td>
  </tr>
</table><br />
<div id="perperiode">
<table width="98%" border="0" align="center">
  <tr>
    <td class="tdat"><h2>Laporan Barang Terjual</h2></td>
  </tr>
</table><br />
<table width="98%" border="0" align="center" class="tabel2">
    <tr height="30">
    	<td align="center" width="3%"><strong>No</strong></td>
        <td align="center" width="5%"><strong>Tanggal</strong></td>
        <td align="center" width="10%"><strong>No Transaksi</strong></td>
        <td align="center" width="20%"><strong>Nama Barang</strong></td>
        <td align="center" width="10%"><strong>Jumlah</strong></td>
        <td align="center" width="10%"><strong>Total Bayar</strong></td>
    </tr>
    <?php
	$querycount="select * from pesanan where status='Lunas' order by tgl_order desc";
	$sql=mysql_query($querycount);
	while($dt=mysql_fetch_array($sql)){
		$notrans=$dt['no_trans'];
		$query = "SELECT * FROM detail_pesanan where no_trans='$notrans'";			
		$result = mysql_query($query) or die('Error');
		$i = 1;
		while($row=mysql_fetch_array($result)){
			$kode=$row['id_produk'];
			$sql1=mysql_query("select * from produk where id_produk=$kode");
			$rs2=mysql_fetch_array($sql1);
			$tgl=$row['tgl_order'];
			$tgl2 = date("d-m-Y", strtotime($tgl));
			$sttl=$rs2['harga_produk']*$row['jumbel'];
	?>
    <tr height="30">
		<td align="center">&nbsp;<?=$c=$c+1;?></td>
        <td align="center">&nbsp;<?=$tgl2; ?></td>
        <td align="center">&nbsp;<?=$row['no_trans']; ?></td>
        <td>&nbsp;<?=$rs2['nama_produk']; ?></td>
        <td align="center">&nbsp;<?=$row['jumbel']; ?></td>
        <td align="center">&nbsp;Rp. <?=$sttl;?>,-</td>
    </tr>
	<?php
   	$i++;
	$ttl=$sttl+$ttl;
	} } ?>
    <tr height="30">
      	<td colspan="5" align="center"><strong>TOTAL PENDAPATAN</strong></td>
      	<td align="center">&nbsp;Rp. <?=$ttl;?>,-</td>
    </tr>
</table>
</div>
<script type="text/javascript">
$('#tgl_akhir').change(function() {
	var awal = $('#tgl_awal').val();
	var akhir = $('#tgl_akhir').val();
	$('#perperiode').load('library/getLaporan.php?a='+awal+'&b='+akhir);
});
</script>
</body>
</html>