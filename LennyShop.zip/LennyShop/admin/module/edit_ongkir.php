<?php
if($_POST)
{
	$update=mysql_query("update ongkir set kota='".$_POST['kota']."', ongkir='".$_POST['ongkir']."' where sha1(id_ongkir)='".$_POST['id']."'");
	if($update)
	{
		?>
        <script>
		alert("Data Ongkos Kirim Berhasil Diperbarui");
		document.location='?page=data_ongkir';
		</script>
        <?php
	}
	else
	{
		?>
        <script>
		alert("Data Ongkos Kirim GAGAL Diperbarui");
		document.location='?page=data_ongkir';
		</script>
        <?php
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
#form1 table tr .tdat h2 {
	font-family: Harrington;
}
</style>
</head>

<body>
<?php
$ID=$_GET['id'];
$lihat=mysql_query("select * from ongkir where sha1(id_ongkir)='$ID'");
$data=mysql_fetch_array($lihat);
?>
<form id="form1" name="form1" method="post" action="">
  <table width="100%" border="0">
    <tr>
      <td class="tdat"><h2>Edit Ongkos Kirim</h2></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td><strong>Nama Kota</strong></td>
    </tr>
    <tr>
      <td><strong>
      <input name="kota" type="text" required id="kota" placeholder="Masukkan Nama Kota" value="<?php echo $data['kota'];?>" size="30" maxlength="30" />
      <input name="id" type="hidden" id="id" value="<?php echo $ID;?>" />
      </strong></td>
    </tr>
    <tr>
      <td><strong>Ongkos Kirim</strong></td>
    </tr>
    <tr>
      <td><strong>
      Rp. 
      <input name="ongkir" type="text" required id="ongkir" placeholder="99999" onKeyPress="return harusangka(event)" value="<?php echo $data['ongkir'];?>" size="20" />
      ,-</strong></td>
    </tr>
    <tr>
      <td><input type="submit" name="Submit" id="bttn" value="  Update  " /></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
    </tr>
  </table>
</form>
</body>
</html>