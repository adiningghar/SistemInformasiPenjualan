<?php
if($_POST['pass']!=$_POST['konf_pass'])
	{
		?>
        <script>
		alert("Password Baru dan Konfirmasi Password Tidak Sesuai");
		document.location="beranda_admin.php";
		</script>
        <?php
	}
	else
	{
		$pass=$_POST['pass'];
		$kon=sha1($_POST['konf_pass']);
		$id=$_POST['em'];
		$update=mysql_query("update admin set password='$kon' where email='$id'");
		if($update)
		{
			?>
            <script>
			alert("Password berhasil diperbarui, Password anda menjadi ~ <?php echo $pass; ?> ~");
			document.location="beranda_admin.php";
			</script>
        	<?php
		}
}
?>