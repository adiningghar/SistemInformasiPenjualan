<?php
if($_POST)
{
	$jumlah = count($_POST["item"]);
	if($jumlah==0)
	{
		?>
        <script>
		alert("Anda Belum Memilih Item!");
		document.location='?page=data_member';
		</script>
        <?php
	}
	else
	{
	for($i=0; $i < $jumlah; $i++) 
	{
		$ID=$_POST["item"][$i];
		$sql="Delete from member where email='$ID'";
		$cek=mysql_query($sql);
	}
	?>
        <script>
		alert("Member Dihapus!");
		document.location='?page=data_member';
		</script>
        <?php
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
#form1 .tabel2 tr td strong {
	color: #636363;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
}
#form1 .tabel2 tr .tdat h2 {
	font-family: Harrington;
}
</style>
</head>

<body>
<form id="form1" name="form1" method="post" action="">
  <table width="100%" border="0" class="tabel2">
    <tr>
      <td colspan="5" class="tdat"><h2>Data Member</h2></td>
    </tr>
    <tr>
      <td width="4%"><strong>Pilih</strong></td>
      <td width="19%"><strong>Nama</strong></td>
      <td width="22%"><strong>Email</strong></td>
      <td width="40%"><strong>Alamat</strong></td>
      <td width="15%"><strong>Nomor Telepon</strong></td>
    </tr>
    <?php
	$dataPerPage = 25;
	if(isset($_GET['Hal']))
	{
		$noPage = $_GET['Hal'];
	} 
	else $noPage = 1;
	$offset = ($noPage - 1) * $dataPerPage;
	$q = "SELECT * FROM member order by nama asc,nama asc limit $offset, $dataPerPage";
	$result = mysql_query($q) or die('Error');
	$i = 1;
	while($row=mysql_fetch_array($result)){
	?>
    <tr valign="top">
      <td align="center"><input name="item[]" type="checkbox" id="item[]" value="<?php echo $row['email'];?>" />
      <label for="item[]"></label></td>
      <td><?php echo $row['nama'];?></td>
      <td><?php echo $row['email'];?></td>
      <td><?php echo $row['alamat'];?></td>
      <td><?php echo $row['no_telp'];?></td>
    </tr>
    <?php } ?>
    <tr>
      <td colspan="5">Hapus yang ditandai? 
      <input type="submit" name="button" id="bttn" value="  Hapus  " /></td>
    </tr>
    <tr>
      <td colspan="5" align="center" class="tdbwh">
      <?php
	  		$query=mysql_query("select count(*) as jumData from member");
			$dt=mysql_fetch_array($query);
			$jumlah=$dt['jumData']; 
			$jumPage = ceil($jumlah/$dataPerPage);
			if ($noPage > 1);
				for($hal = 1; $hal <= $jumPage; $hal++)
				{
				if ((($hal >= $noPage - 3) && ($hal <= $noPage + 3)) || ($hal == 1) || ($hal == $jumPage)) 
				{   
				if (($showPage == 1) && ($hal != 2))  echo "..."; 
				if (($showPage != ($jumPage - 1)) && ($hal == $jumPage))  echo "...";
				if ($hal == $noPage) echo " <b>".$hal."</b> ";
			else echo " <a class='ahref' href='".$_SERVER['PHP_SELF']."?page=data_member&Hal=".$hal."'>".$hal."</a> ";
				$showPage = $hal;          
				}
			}
			if ($noPage < $jumPage);
									
		?>
      </td>
    </tr>
  </table>
</form>
<br />
</body>
</html>