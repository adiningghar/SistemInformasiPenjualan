<?php
if($_POST)
{
	$update=mysql_query("update kategori_produk set nama_kategori='".$_POST['nama_kategori']."' where sha1(id_kategori)='".$_POST['id_kategori']."'");
	if($update)
	{
		?>
        <script>
		alert("Data Kategori Berhasil Diperbarui");
		document.location='?page=data_kategori';
		</script>
        <?php
	}
	else
	{
		?>
        <script>
		alert("Data Kategori Gagal Diperbarui");
		document.location='?page=data_kategori';
		</script>
        <?php
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
#form1 table tr .tdat h2 {
	font-family: Harrington;
}
</style>
</head>

<body>
<?php
$ID=$_GET['id'];
$lihat=mysql_query("select * from kategori_produk where sha1(nama_kategori)='$ID'");
$data=mysql_fetch_array($lihat);
?>
<form id="form1" name="form1" method="post" action="">
  <table width="100%" border="0">
    <tr>
      <td class="tdat"><h2>Edit Kategori Produk</h2></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
    </tr>
    
    <tr>
      <td><strong>Nama Kategori</strong></td>
    </tr>
    <tr>
      <td><strong>
      <input name="kategori[]" type="text" required id="kategori[]" value="<?php echo $data['nama_kategori'];?>" size="20" /></strong></td>
    </tr>
    <tr>
      <td><input type="submit" name="submit" id="bttn" value="Update" /></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
    </tr>
  </table>
</form>
</body>
</html>