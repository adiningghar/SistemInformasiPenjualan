<?php
if($_POST)
{
	$jumlah = count($_POST["item"]);
	if($jumlah==0)
	{
		?>
        <script>
		alert("Anda Belum Memilih Item!");
		document.location='?page=data_konfirmasi';
		</script>
        <?php
	}
	else
	{
	for($i=0; $i < $jumlah; $i++) 
	{
		$ID=$_POST["item"][$i];
		$sql="Delete from konfirmasi_bayar where sha1(id_konfirmasi)='$ID'";
		$cek=mysql_query($sql);
	}
	?>
        <script>
		alert("Data Konfirmasi Bayar Dihapus!");
		document.location='?page=data_konfirmasi';
		</script>
        <?php
	}
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
#form1 .tabel2 tr td strong {
	color: #636363;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
}
</style>
</head>

<body>
<form id="form1" name="form1" method="post" action="">
  <table width="98%" border="0" align="center" style="border: solid 1px #EEE; font-family: Harrington;">
  <tr>
    <td class="tdat"><h2>Data Konfirmasi Pembayaran</h2></td>
  </tr>
</table><br />
    <table width="98%" border="0" align="center" class="tabel2">
    <tr>
      <td width="5%"><strong>Pilih</strong></td>
      <td width="16%"><strong>Nomor Transaksi</strong></td>
      <td width="12%"><strong>Tanggal</strong></td>
      <td width="20%"><strong>Bank Tujuan</strong></td>
      <td width="16%"><strong>Nomor Rekening</strong></td>
      <td width="16%"><strong>Atas Nama</strong></td>
      <td width="15%"><strong>Jumlah Transfer</strong></td>
    </tr>
    <?php
	$dataPerPage = 25;
	if(isset($_GET['Hal']))
	{
		$noPage = $_GET['Hal'];
	} 
	else $noPage = 1;
	$offset = ($noPage - 1) * $dataPerPage;
	$q = "SELECT * FROM konfirmasi_bayar order by tgl_konfirmasi desc, tgl_konfirmasi desc limit $offset, $dataPerPage";
	$result = mysql_query($q) or die('Error');
	$i = 1;
	while($row=mysql_fetch_array($result)){
	?>
    <tr>
      <td align="center"><input name="item[]" type="checkbox" id="item[]" value="<?php echo sha1($row['id_konfirmasi']);?>" />
      <label for="item[]"></label></td>
      <td><?php echo $row['no_trans'];?></td>
      <td><?php echo $row['tgl_konfirmasi'];?></td>
      <td><?php echo $row['bank_tujuan'];?></td>
      <td><?php echo $row['no_rek'];?></td>
      <td><?php echo $row['atasnama'];?></td>
      <td>Rp. <?php echo $row['jumlah_transfer'];?>,-</td>
    </tr>
    <?php } ?>
    <tr>
      <td colspan="7">Hapus yang ditandai? 
      <input type="submit" name="Submit" id="bttn" value="  Hapus  " /></td>
    </tr>
    <tr>
      <td colspan="7" align="center" class="tdbwh">
      <?php
	  		$query=mysql_query("select count(*) as jumData from konfirmasi_bayar");
			$dt=mysql_fetch_array($query);
			$jumlah=$dt['jumData']; 
			$jumPage = ceil($jumlah/$dataPerPage);
			if ($noPage > 1);
				for($hal = 1; $hal <= $jumPage; $hal++)
				{
				if ((($hal >= $noPage - 3) && ($hal <= $noPage + 3)) || ($hal == 1) || ($hal == $jumPage)) 
				{   
				if (($showPage == 1) && ($hal != 2))  echo "..."; 
				if (($showPage != ($jumPage - 1)) && ($hal == $jumPage))  echo "...";
				if ($hal == $noPage) echo " <b>".$hal."</b> ";
			else echo " <a class='ahref' href='".$_SERVER['PHP_SELF']."?page=data_konfirmasi&Hal=".$hal."'>".$hal."</a> ";
				$showPage = $hal;          
				}
			}
			if ($noPage < $jumPage);
									
		?>
      </td>
    </tr>
  </table>
</form>
<br />
</body>
</html>