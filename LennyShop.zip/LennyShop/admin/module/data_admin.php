<?php
$aksi=$_GET['aksi'];
$id=$_GET['id'];

if($aksi=="hapus")
{
	$hapus=mysql_query("delete from admin where email='$id'");
	if($hapus)
	{
		?>
        <script>
		alert("Data Admin Berhasil Dihapus");
		document.location='?page=data_admin';
		</script>
        <?php
	}
	else
	{
		?>
        <script>
		alert("Data Admin GAGAL Dihapus");
		document.location='?page=data_admin';
		</script>
        <?php
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
.tabel2 tr td strong {
	color: #636363;
	font-size: 12px;
	font-family: Arial, Helvetica, sans-serif;
}
.tabel2 tr .tdat h2 {
	font-family: Harrington;
}
</style>
</head>

<body>
<table width="100%" border="0" class="tabel2">
  <tr>
    <td colspan="4" class="tdat"><h2>Data Administrator</h2></td>
  </tr>
  <tr>
    <td width="4%"><strong>No.</strong></td>
    <td width="36%"><strong>Nama Administrator</strong></td>
    <td width="49%"><strong>Email Administrator</strong></td>
    <td width="11%"><strong>Opsi</strong></td>
  </tr>
  <?php
  $lihat=mysql_query("select * from admin order by email asc");
  while($data=mysql_fetch_array($lihat)){
	  if($data['email']=="admin@ktishop.com")
	  {
		  $a="#";
	  }
	  else
	  {
		  $a="?page=data_admin&aksi=hapus&id=$data[email]";
	  }
  ?>
  <tr>
    <td><?php echo $no=$no+1;?></td>
    <td><?php echo $data['nama'];?></td>
    <td><?php echo $data['email'];?></td>
    <td><a href="<?php echo $a;?>" class="ahref">Hapus</a></td>
  </tr>
  <?php } ?>
</table>
</body>
</html>