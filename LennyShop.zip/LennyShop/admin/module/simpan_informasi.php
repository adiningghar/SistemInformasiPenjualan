<?php
$judul=$_POST['judul'];
$isi=$_POST['isi'];

$simpan=mysql_query("insert into informasi values('','$judul','$isi')");
if($simpan)
{
	?>
    <script>
	alert("Informasi Berhasil Ditambahkan");
	document.location='?page=data_informasi';
	</script>
    <?php
}
else
{
	?>
    <script>
	alert("Informasi GAGAL Ditambahkan");
	document.location='?page=input_informasi';
	</script>
    <?php
}

?>