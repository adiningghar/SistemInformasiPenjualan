<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
#form1 .tabel2 tr td strong {
	color: #636363;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
}
#form1 .tabel2 tr .tdat h2 {
	font-family: Harrington;
}
</style>
</head>

<body>
<?php
$ID=$_GET['idk'];
$sK=mysql_query("select * from kategori_produk where sha1(id_kategori)='$ID'");
$dK=mysql_fetch_array($sK);
?>
<form id="form1" name="form1" method="post" action="?page=aksi_produk">
  <table width="100%" border="0" class="tabel2">
    <tr>
      <td colspan="8" class="tdat"><h2>Data Produk <?php echo $dK['nama_kategori'];?>
        <input name="aksi" type="hidden" id="aksi" value="hapus" />
        <input type="hidden" name="idk" id="idk" value="<?php echo $dK['id_kategori'];?>" />
      </h2></td>
    </tr>
    <tr>
      <td width="3%"><strong>Pilih</strong></td>
      <td width="16%"><strong>Gambar</strong></td>
      <td width="14%"><strong>Nama Produk</strong></td>
      <td width="15%"><strong>Harga Produk</strong></td>
      <td width="9%"><strong>Stok</strong></td>
      <td width="9%"><strong>Berat</strong></td>
      <td width="28%"><strong>Deskripsi Produk</strong></td>
      <td width="6%"><strong>Opsi</strong></td>
    </tr>
    <?php
	$strSQL = "SELECT * FROM produk where sha1(id_kategori)='$ID'";
    $objQuery = mysql_query($strSQL);
    $Num_Rows = mysql_num_rows($objQuery);
                    
    $Per_Page = 5;   // Per Page
    $Page = $_GET["Page"];
    if(!$_GET["Page"])
    {
        $Page=1;
    }
                    
    $Prev_Page = $Page-1;
    $Next_Page = $Page+1;
    $Page_Start = (($Per_Page*$Page)-$Per_Page);
    if($Num_Rows<=$Per_Page)
    {
        $Num_Pages =1;
    }
    else if(($Num_Rows % $Per_Page)==0)
    {
        $Num_Pages =($Num_Rows/$Per_Page) ;
    }
    else
    {
        $Num_Pages =($Num_Rows/$Per_Page)+1;
        $Num_Pages = (int)$Num_Pages;
    }
                    
    $strSQL .=" order  by nama_produk ASC LIMIT $Page_Start , $Per_Page";
    $objQuery  = mysql_query($strSQL);
	$intRows = 0;
	while($row_barang=mysql_fetch_array($objQuery)){
?>
    <tr>
      <td align="center" valign="top"><input name="item[]" type="checkbox" id="item[]" value="<?php echo sha1($row_barang['id_produk']);?>" />
      <label for="item[]"></label></td>
      <td><img src="produk/<?php echo $row_barang['gambar'];?>" width="165" height="151" class="mg1" /></td>
      <td><?php echo $row_barang['nama_produk'];?></td>
      <td>Rp. <?php echo $row_barang['harga_produk'];?></td>
      <td><?php echo $row_barang['stok'];?></td>
      <td><?php echo $row_barang['berat'];?> Kg</td>
      <td><?php echo $row_barang['keterangan'];?></td>
      <td><strong><a href="?page=edit_produk&idp=<?php echo sha1($row_barang['id_produk']);?>" class="ahref">Edit</a></strong></td>
    </tr>
    <?php } ?>
    <tr>
      <td colspan="8">Hapus yang ditandai? 
      <input type="submit" name="button" id="bttn" value="  Hapus  " /></td>
    </tr>
    <tr>
      <td colspan="8" align="center" class="tdbwh"><strong>
      Total <?= $Num_Rows;?> Record : <?=$Num_Pages;?> Page :
      <?
      if($Prev_Page)
      {
           echo " <a href='$_SERVER[SCRIPT_NAME]?page=data_produk&Page=$Prev_Page&idk=$ID'><<=Sebelumnya</a> ";
      }
                        
      for($i=1; $i<=$Num_Pages; $i++){
      	if($i != $Page)
        {
             echo "<a href='$_SERVER[SCRIPT_NAME]?page=data_produk&Page=$i&idk=$ID'>$i</a>&nbsp;";
        }
        else
        {
             echo "<b> $i </b>";
        }
      }
      if($Page!=$Num_Pages)
      {
           echo " <a href ='$_SERVER[SCRIPT_NAME]?page=data_produk&Page=$Next_Page&idk=$ID'>Selanjutnya=>></a> ";
      }
?>
      </strong></td>
    </tr>
  </table>
</form>
<br />
</body>
</html>