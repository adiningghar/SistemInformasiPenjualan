<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
.table-galeri {
	color: #636363;
	font-size: 12px;
	font-family: Arial, Helvetica, sans-serif;
}
.table-galeri1 {
	color: #636363;
	font-size: 12px;
	font-family: Arial, Helvetica, sans-serif;
}
.tabel-hapus {
	color: #636363;
	font-size: 12px;
	font-family: Arial, Helvetica, sans-serif;
}
</style>
</head>

<body>
<form action="?page=hapus_galeri" method="post">
<table width="98%" border="0" align="center" style="border: 1px #EEE solid; font-family: Harrington;">
  <tr>
    <td colspan="2" class="tdat"><h2>Data Galeri</h2></td>
    </tr>
    </table><br />
    <table width="98%" border="0" align="center">
  <tr align="center">
    <td width="9%"><strong class="table-galeri1">Pilih</strong></td>
    <td width="91%" align="left"><strong class="table-galeri">Foto yang ditampilkan</strong></td>
    </tr>
    <?php
	$dataPerPage = 5;
	if(isset($_GET['Page']))
	{
		$noPage = $_GET['Page'];
	} 
	else $noPage = 1;
	$offset = ($noPage - 1) * $dataPerPage;
							
	$sql=mysql_query("select * from galeri order by id_galeri desc,id_galeri desc limit $offset, $dataPerPage");
	while($row=mysql_fetch_array($sql)){
	?>
  <tr>
    <td align="center" valign="top"><input type="checkbox" name="item[]" id="item[]" value="<?php echo $row['id_galeri'];?>" />
      <label for="item[]"></label></td>
    <td><img src="../galeri/<?php echo $row['foto'];?>" width="349" height="200px" style="-moz-border-radius:10px; -webkit-border-radius:10px; border-radius:10px;" /></td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
    <?php } ?>
  <tr>
    <td>&nbsp;</td>
    <td><strong class="tabel-hapus">Hapus yang ditandai?
      <input type="submit" name="button" id="button" value="Hapus" />
    </strong></td>
    </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2" align="center">
    <?
									// mencari jumlah semua data dalam tabel guestbook
									
									$query= "SELECT COUNT(*) AS jumData FROM galeri";
									$hasil= mysql_query($query);
									$data= mysql_fetch_array($hasil);
									
									$jumData = $data['jumData'];
									
									// menentukan jumlah halaman yang muncul berdasarkan jumlah semua data
									
									$jumPage = ceil($jumData/$dataPerPage);
									
									// menampilkan link previous
									
									if ($noPage > 1);
									
										// memunculkan nomor halaman dan linknya
									
										for($page = 1; $page <= $jumPage; $page++)
											{
												if ((($page >= $noPage - 3) && ($page <= $noPage + 3)) || ($page == 1) || ($page == $jumPage)) 
												{   
													if (($showPage == 1) && ($page != 2))  echo "..."; 
													if (($showPage != ($jumPage - 1)) && ($page == $jumPage))  echo "...";
													if ($page == $noPage) echo " <b>".$page."</b> ";
													else echo " <a class='ah1' href='".$_SERVER['PHP_SELF']."?page=galeri&Page=".$page."'>".$page."</a> ";
													$showPage = $page;          
												}
											}
									
										// menampilkan link next
									
										if ($noPage < $jumPage);
									
								?>
    </td>
    </tr>
</table>
</form>
<p align="center"><a href="?page=tambah_galeri" class="ahref"><strong>Input Galeri Baru</strong></a></p>
</body>
</html>