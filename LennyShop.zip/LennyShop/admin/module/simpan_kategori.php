<?php
$jumlah = count($_POST["kategori"]);
$jml = count(!empty($_POST["kategori"]));

if($jml==0)
{
	?>
    <script>
	alert("Anda Belum Mengisi Data Satu Pun, Minimal Anda Harus Isi Satu Data");
	document.location='?page=tambah_kategori';
	</script>
    <?php
}
else
{
for($i=0; $i < $jumlah; $i++) 
{
	if(!empty($_POST["kategori"][$i]))
	{
	$nama=$_POST["kategori"][$i];
	
	$sql="insert into kategori_produk values ('','$nama')";
	$cek=mysql_query($sql);
	}
}
	?>
		<script language="javascript">
			alert("Kategori Berhasil Ditambahkan");
			document.location="?page=data_kategori";
		</script>
    <?php
}
?>
		