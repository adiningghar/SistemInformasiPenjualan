<?php
$namafolder="../galeri/";
for($i=0; $i<count($_FILES['file']); $i++) 
{
  if (!empty($_FILES["file"]["tmp_name"][$i]))
  {
    $jenis_gambar=$_FILES['file']['type'][$i];
    if($jenis_gambar=="image/jpeg" || $jenis_gambar=="image/jpg" || $jenis_gambar=="image/x-png")
    { 
      $gambar = $namafolder . basename($_FILES['file']['name'][$i]); 
	  $namafile=$_FILES['file']['name'][$i];
      if (move_uploaded_file($_FILES['file']['tmp_name'][$i], $gambar)) {
		  $sql=mysql_query("insert into galeri values('','$namafile')");
		  ?>
          <script>
		  alert("Galeri Ditambahkan");
		  document.location='?page=galeri';
		  </script>
          <?php
	} 
  } 
     else 
     {
 ?>
          <script>
		  alert("Galeri GAGAL Ditambahkan, Format Gambar Tidak Diterima Sistem");
		  document.location='?page=galeri';
		  </script>
          <?php
     }
   }
}
?>