<?php
$nama=$_POST['nama'];
$email=$_POST['email'];
$pass=sha1($_POST['password']);

$simpan=mysql_query("insert into admin values('$email','$nama','$pass')");
	if($simpan)
	{
		?>
        <script>
		alert("Admin Baru Berhasil Ditambahkan");
		document.location='?page=data_admin';
		</script>
        <?php
	}
	else
	{
		?>
        <script>
		alert("Pendaftaran GAGAL, Email Sudah Terdaftar!");
		document.location='?page=tambah_admin';
		</script>
        <?php
	}
?>