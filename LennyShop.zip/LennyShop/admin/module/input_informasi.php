<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
#form1 table tr td strong {
	color: #636363;
	font-size: 12px;
	font-family: Arial, Helvetica, sans-serif;
}
#form1 table tr .tdat h2 {
	font-family: Harrington;
}
</style>
</head>

<body>
<form id="form1" name="form1" method="post" action="?page=simpan_informasi">
  <table width="100%" border="0">
    <tr>
      <td class="tdat"><h2>Input Informasi</h2></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td><strong>Judul Informasi</strong></td>
    </tr>
    <tr>
      <td><strong>
      <input name="judul" type="text" id="judul" size="40" maxlength="50" placeholder="Masukkan Judul Informasi" required="required" />
      </strong></td>
    </tr>
    <tr>
      <td><strong>Isi Informasi</strong></td>
    </tr>
    <tr>
      <td><strong>
      <textarea name="isi" id="isi" cols="80" rows="10" required="required" class="ckeditor"></textarea>
      </strong></td>
    </tr>
    <tr>
      <td><input type="submit" name="Submit" id="bttn" value="  Simpan  " />
      <input type="reset" name="button2" id="bttn" value="  Batal  " /></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
    </tr>
  </table>
</form>
</body>
</html>