<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
#form1 table tr td strong {
	color: #636363;
	font-size: 12px;
	font-family: Arial, Helvetica, sans-serif;
}
#form1 table tr .tdat h2 {
	font-family: Harrington;
}
</style>
</head>

<body>
<form action="?page=aksi_produk" method="post" enctype="multipart/form-data" name="form1" id="form1">
  <table width="100%" border="0">
    <tr>
      <td class="tdat"><h2>Tambah Produk
        <input name="aksi" type="hidden" id="aksi" value="simpan" />
      </h2></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td><strong>Pilih Kategori Produk</strong></td>
    </tr>
    <tr>
      <td><label for="kat"></label>
        <select name="kat" id="kat">
        <?php
		$queryKat=mysql_query("select * from kategori_produk order by nama_kategori asc");
		while($dtKat=mysql_fetch_array($queryKat)){
		?>
          <option value="<?php echo $dtKat['id_kategori'];?>"><?php echo $dtKat['nama_kategori'];?></option>
          <?php } ?>
      </select></td>
    </tr>
    <tr>
      <td><strong>Nama Produk</strong></td>
    </tr>
    <tr>
      <td><label for="nama_produk"></label>
      <input name="nama_produk" type="text" id="nama_produk" size="30" maxlength="30" placeholder="Masukkan Nama Produk" required="required" /></td>
    </tr>
    <tr>
      <td><strong>Harga Produk</strong></td>
    </tr>
    <tr>
      <td><label for="harga_produk"></label>
      Rp. <input type="text" name="harga_produk" id="harga_produk" size="20" placeholder="99999" onkeypress="return harusangka(event)" required="required" />,-</td>
    </tr>
    <tr>
      <td><strong>Deskripsi Produk</strong></td>
    </tr>
    <tr>
      <td><label for="deskripsi"></label>
      <textarea name="deskripsi" id="deskripsi" cols="60" rows="10" required="required" class="ckeditor"></textarea></td>
    </tr>
    <tr>
      <td><strong>Stok</strong></td>
    </tr>
    <tr>
      <td><label for="stok"></label>
      <input type="text" name="stok" id="stok" size="10" placeholder="999" required="required" onkeypress="return harusangka(event)" /></td>
    </tr>
    <tr>
      <td><strong>Berat Produk</strong></td>
    </tr>
    <tr>
      <td><label for="berat"></label>
      <input name="berat" type="text" id="berat" size="10" required="required" placeholder="9.9" /> 
      Kg <br />/*<strong>(Contoh Penulisan Berat : 2.5)</strong></td>
    </tr>
    <tr>
      <td><strong>Upload Gambar</strong></td>
    </tr>
    <tr>
      <td><label for="gambar"></label>
      <input type="file" name="gambar" id="gambar" required="required" /></td>
    </tr>
    <tr>
      <td><input type="submit" name="button" id="bttn" value="  Simpan  " />
      <input type="reset" name="button2" id="bttn" value="  Batal  " /></td>
    </tr>
  </table>
</form>
<br />
</body>
</html>