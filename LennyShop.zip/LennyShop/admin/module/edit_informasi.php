<?php
if($_POST)
{
	$update=mysql_query("update informasi set judul='".$_POST['judul']."', isi='".$_POST['isi']."' where sha1(id_informasi)='".$_POST['id_info']."'");
	if($update)
	{
		?>
        <script>
		alert("Informasi Berhasil Diperbarui");
		document.location='?page=data_informasi';
		</script>
        <?php
	}
	else
	{
		?>
        <script>
		alert("Informasi GAGAL Diperbarui");
		document.location='?page=data_informasi';
		</script>
        <?php
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
#form1 table tr .tdat h2 {
	font-family: Harrington;
}
</style>
</head>

<body>
<?php
$ID=$_GET['id'];
$lihat=mysql_query("select * from informasi where sha1(id_informasi)='$ID'");
$data=mysql_fetch_array($lihat);
?>
<form id="form1" name="form1" method="post" action="">
  <table width="100%" border="0">
    <tr>
      <td class="tdat"><h2>Edit Informasi</h2></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td><strong>Judul Informasi</strong></td>
    </tr>
    <tr>
      <td><strong>
      <input name="judul" type="text" required id="judul" placeholder="Masukkan Judul Informasi" value="<?php echo $data['judul'];?>" size="40" maxlength="50" />
      <input name="id_info" type="hidden" id="id_info" value="<?php echo $ID;?>" />
      </strong></td>
    </tr>
    <tr>
      <td><strong>Isi Informasi</strong></td>
    </tr>
    <tr>
      <td><strong>
      <textarea name="isi" id="isi" cols="80" rows="10" required class="ckeditor"><?php echo $data['isi'];?></textarea>
      </strong></td>
    </tr>
    <tr>
      <td><input type="submit" name="Submit" id="bttn" value="  Update  " /></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
    </tr>
  </table>
</form>
</body>
</html>