<?php
if($_POST)
{
	$jumlah = count($_POST["item"]);
	if($jumlah==0)
	{
		?>
        <script>
		alert("Anda Belum Memilih Item!");
		document.location='?page=data_ongkir';
		</script>
        <?php
	}
	else
	{
	for($i=0; $i < $jumlah; $i++) 
	{
		$ID=$_POST["item"][$i];
		$sql="Delete from ongkir where sha1(id_ongkir)='$ID'";
		$cek=mysql_query($sql);
	}
	?>
        <script>
		alert("Data Ongkos Kirim Dihapus!");
		document.location='?page=data_ongkir';
		</script>
        <?php
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
#form1 .tabel2 tr td strong {
	color: #636363;
	font-size: 12px;
	font-family: Arial, Helvetica, sans-serif;
}
#form1 .tabel2 tr .tdat h2 {
	font-family: Harrington;
}
</style>
</head>

<body>
<form id="form1" name="form1" method="post" action="">
  <table width="100%" border="0" class="tabel2">
    <tr>
      <td colspan="4" class="tdat"><h2>Data Ongkos Kirim</h2></td>
    </tr>
    <tr>
      <td width="5%"><strong>Pilih</strong></td>
      <td width="39%"><strong>Nama Kota</strong></td>
      <td width="41%"><strong>Ongkos Kirim</strong></td>
      <td width="15%"><strong>Opsi</strong></td>
    </tr>
    <?php
	$dataPerPage = 25;
	if(isset($_GET['Hal']))
	{
		$noPage = $_GET['Hal'];
	} 
	else $noPage = 1;
	$offset = ($noPage - 1) * $dataPerPage;
	$q = "SELECT * FROM ongkir order by kota asc, kota asc limit $offset, $dataPerPage";
	$result = mysql_query($q) or die('Error');
	$i = 1;
	while($row=mysql_fetch_array($result)){
	?>
    <tr>
      <td align="center"><input name="item[]" type="checkbox" id="item[]" value="<?php echo sha1($row['id_ongkir']);?>" />
      <label for="item[]"></label></td>
      <td><?php echo $row['kota'];?></td>
      <td>Rp. <?php echo $row['ongkir'];?>,-</td>
      <td><a href="?page=edit_ongkir&id=<?php echo sha1($row['id_ongkir']);?>" class="ahref"><strong>Edit</strong></a></td>
    </tr>
    <?php } ?>
    <tr>
      <td colspan="4">Hapus yang ditandai? 
      <input type="submit" name="Submit" id="bttn" value="  Hapus  " /></td>
    </tr>
    <tr>
      <td colspan="4" align="center" class="tdbwh">
      <?php
	  		$query=mysql_query("select count(*) as jumData from ongkir");
			$dt=mysql_fetch_array($query);
			$jumlah=$dt['jumData']; 
			$jumPage = ceil($jumlah/$dataPerPage);
			if ($noPage > 1);
				for($hal = 1; $hal <= $jumPage; $hal++)
				{
				if ((($hal >= $noPage - 3) && ($hal <= $noPage + 3)) || ($hal == 1) || ($hal == $jumPage)) 
				{   
				if (($showPage == 1) && ($hal != 2))  echo "..."; 
				if (($showPage != ($jumPage - 1)) && ($hal == $jumPage))  echo "...";
				if ($hal == $noPage) echo " <b>".$hal."</b> ";
			else echo " <a class='ahref' href='".$_SERVER['PHP_SELF']."?page=data_ongkir&Hal=".$hal."'>".$hal."</a> ";
				$showPage = $hal;          
				}
			}
			if ($noPage < $jumPage);
									
		?>
      </td>
    </tr>
  </table>
</form>
<br />
</body>
</html>