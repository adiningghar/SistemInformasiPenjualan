<?php
$kota=$_POST['kota'];
$ongkir=$_POST['ongkir'];

$simpan=mysql_query("insert into ongkir values ('','$kota','$ongkir')");
if($simpan)
{
	?>
    <script>
	alert('Ongkos kirim Berhasil Ditambahkan');
	document.location='?page=data_ongkir';
	</script>
    <?php
}
else
{
	?>
    <script>
	alert('Ongkos kirim GAGAL Ditambahkan');
	document.location='?page=input_ongkir';
	</script>
    <?php
}
?>