<?php
$aksi=$_POST['aksi'];
$kat=$_POST['kat'];
$nama=$_POST['nama_produk'];
$harga=$_POST['harga_produk'];
$des=$_POST['deskripsi'];
$stok=$_POST['stok'];
$berat=$_POST['berat'];

if($aksi=='simpan')
{
//upload file
	if(!empty($_FILES) && $_FILES['gambar']['size'] > 0 && $_FILES['gambar']['error'] == 0){
		$fileName = $_FILES['gambar']['name'];
		$move = move_uploaded_file($_FILES['gambar']['tmp_name'],'produk/'.$fileName);
		if($move){
			$sql = "insert into produk values ('','$nama','$harga','$des','$stok','$berat','$fileName','$kat','0')";
			$cek=mysql_query($sql);
			$kd=sha1($kat);
			if($cek)
			{
				echo"<script>";
				echo"alert('Data Produk Berhasil Ditambahkan');";
				echo"window.location='?page=data_produk&idk=$kd'";
				echo"</script>";
				exit;
			}
			else
				echo"Gagal";
		}
	}
}
elseif($aksi=="hapus")
{
	$jumlah = count($_POST["item"]);
	$idk=$_POST['idk'];
		if($jumlah==0)
		{
			?>
        	<script>
			alert("Anda Belum Memilih Item!");
			document.location='?page=data_produk&idk=<?php echo sha1($idk);?>';
			</script>
        	<?php
		}
		else
		{
			for($i=0; $i < $jumlah; $i++) 
			{
				$ID=$_POST["item"][$i];
				$sql = "select * from produk where sha1(id_produk)='$ID'";  
    			$result = mysql_query($sql);  
	
    			if(mysql_num_rows($result) > 0 ){  
        		$data = mysql_fetch_array($result);  
				$kode=sha1($data['id_kategori']);
          
        		@unlink('produk/'.$data['gambar']);  
          
        		mysql_query("delete from produk where sha1(id_produk)='$ID'");  
    			}
			}
			echo"<script>";
			echo"alert('Data Produk Berhasil Dihapus');";
			echo"window.location='?page=data_produk&idk=$kode'";;
			echo"</script>";
		}
}
?>