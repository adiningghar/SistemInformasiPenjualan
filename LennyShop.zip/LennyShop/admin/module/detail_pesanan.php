<?php
if($_POST)
{
	$q=mysql_query("update pesanan set status='".$_POST['status']."' where no_trans='".$_POST['idt']."'");
	if($q)
	{
		?>
        <script>
		document.location='?page=data_pesanan';
		</script>
        <?php
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>

</head>

<body>
<table width="98%" border="0" align="center" style="border: solid 1px #EEE; font-family: Harrington;">
  <tr>
    <td bgcolor="#EEE"><h2>Detail History Order</h2></td>
  </tr>
</table>
<?php
$no_trans=$_GET['no'];
$qPesan=mysql_query("select * from pesanan where no_trans='$no_trans'");
$rPesan=mysql_fetch_array($qPesan);
$email=$rPesan['email'];

$pmsn=mysql_query("select * from member where email='$email'");
$dtPmsn=mysql_fetch_array($pmsn);
if($rPesan['status']=="Pesan")
	$sp="selected";
else
	$sl="selected";
?>
<table width="98%" border="0" align="center">
  <tr>
    <td colspan="5"><strong>=&gt; Data Pemesanan</strong></td>
  </tr>
  <tr>
    <td>Nomor Transaksi</td>
    <td width="74%" colspan="3"><?php echo $rPesan['no_trans'];?></td>
  </tr>
  <tr>
    <td>Tgl/waktu</td>
    <td colspan="3"><?php echo $rPesan['tgl_order'];?>/<?php echo $rPesan['jam_order'];?></td>
  </tr>
  <tr>
    <td>Nama Pemesan</td>
    <td colspan="3"><?php echo $dtPmsn['nama'];?></td>
  </tr>
  <tr>
    <td>Alamat Pengiriman</td>
    <td colspan="3"><?php echo $rPesan['alamat_pengiriman'];?></td>
  </tr>
  <tr>
    <td>Status Order</td>
    <td colspan="3"><form id="form1" name="form1" method="post" action="">
      <label for="status"></label>
      <select name="status" id="status">
        <option value="Pesan" <?php echo $sp;?> >Pesan</option>
        <option value="Lunas" <?php echo $sl;?> >Lunas</option>
      </select>
      <input type="submit" name="button" id="button" value="  Ok  " />
      <input name="idt" type="hidden" id="idt" value="<?php echo $no_trans;?>" />
    </form></td>
  </tr>
  <tr>
    <td colspan="5">&nbsp;</td>
  </tr>
  </table>
  <table width="98%" border="0" align="center" class="tabel2">
  <tr>
    <td colspan="5"><strong>=&gt; Detail Pemesanan</strong></td>
  </tr>
  <tr>
    <td width="4%"><strong>No.</strong></td>
    <td width="32%"><strong>Nama Produk</strong></td>
    <td width="21%"><strong>Harga Produk</strong></td>
    <td width="19%"><strong>Jumlah Beli</strong></td>
    <td width="19%"><strong>Subtotal</strong></td>
  </tr>
  <?php
  $qDP=mysql_query("select * from detail_pesanan where no_trans='$no_trans'");
  while($rDP=mysql_fetch_array($qDP)){
	  $idp=$rDP['id_produk'];
	  $qBrg=mysql_query("select * from produk where id_produk='$idp'");
	  $dBrg=mysql_fetch_array($qBrg);
	  $sub=$rDP['harga_produk']*$rDP['jumbel'];
  ?>
  <tr>
    <td><?php echo $no=$no+1;?></td>
    <td><?php echo $dBrg['nama_produk'];?></td>
    <td>Rp. <?php echo $rDP['harga_produk'];?>,-</td>
    <td><?php echo $rDP['jumbel'];?></td>
    <td>Rp. <?php echo $sub;?>,-</td>
  </tr>
  <?php } ?>
  <tr>
    <td colspan="4" align="center"><strong>Ongkos Kirim</strong></td>
    <td>Rp. <?php echo $rPesan['ongkir'];?>,-</td>
  </tr>
  <tr>
    <td colspan="4" align="center"><strong>Total Bayar</strong></td>
    <td>Rp. <?php echo $tot=$rPesan['total']+$rPesan['ongkir'];?>,-</td>
  </tr>
  <tr>
    <td colspan="5"><strong>NB : Cetak struk ini dan segera lakukan transfer sesuai dengan total bayar yang tertera.</strong></td>
  </tr>
</table>
<br />
</body>
</html>