<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
#form1 table tr td strong {
	color: #636363;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
}
#form1 table tr .tdat h2 {
	font-family: Harrington;
}
</style>
</head>

<body>
<form id="form1" name="form1" method="post" action="?page=simpan_kategori">
  <table width="100%" border="0">
    <tr>
      <td colspan="2" class="tdat"><h2>Tambah Kategori Produk</h2></td>
    </tr>
    <tr>
      <td width="19%">&nbsp;</td>
      <td width="81%">&nbsp;</td>
    </tr>
    <tr>
      <td><strong>Nama Kategori</strong></td>
      <td><strong>
      <input name="kategori[]" type="text" id="kategori[]" size="30" maxlength="30" placeholder="Masukkan Nama Kategori" />
      </strong></td>
    </tr>
    <tr>
      <td><strong>Nama Kategori</strong></td>
      <td><strong>
      <input name="kategori[]" type="text" id="kategori[]" size="30" maxlength="30" placeholder="Masukkan Nama Kategori" />
      </strong></td>
    </tr>
    <tr>
      <td><strong>Nama Kategori</strong></td>
      <td><strong>
        <input name="kategori[]" type="text" id="kategori[]" size="30" maxlength="30" placeholder="Masukkan Nama Kategori" />
      </strong></td>
    </tr>
    <tr>
      <td><strong>Nama Kategori</strong></td>
      <td><strong>
        <input name="kategori[]" type="text" id="kategori[]" size="30" maxlength="30" placeholder="Masukkan Nama Kategori" />
      </strong></td>
    </tr>
    <tr>
      <td><strong>Nama Kategori</strong></td>
      <td><strong>
        <input name="kategori[]" type="text" id="kategori[]" size="30" maxlength="30" placeholder="Masukkan Nama Kategori" />
      </strong></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><input type="submit" name="button" id="bttn" value="  Simpan  " />
      <input type="reset" name="button2" id="bttn" value="  Batal  " /></td>
    </tr>
  </table>
</form>
</body>
</html>