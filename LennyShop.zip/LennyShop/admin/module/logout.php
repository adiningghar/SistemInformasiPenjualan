<?php 
session_start();
	unset($_SESSION['admin']);
	unset($_SESSION['idadmin']);
	?>
	<script language="javascript">
	alert("Anda Telah Logout");
	document.location="../index.php";
	</script> 