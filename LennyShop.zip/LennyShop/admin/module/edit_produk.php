<?php 
	if($_POST){
			$update = "update produk set id_kategori='".$_POST['kat']."',keterangan='".$_POST['deskripsi']."',nama_produk='".$_POST['nama_produk']."',harga_produk='".$_POST['harga_produk']."', stok='".$_POST['stok']."',berat='".$_POST['berat']."'";
			if($_FILES['gambar']['size'] > 0 && $_FILES['gambar']['error'] == 0){
				$move = move_uploaded_file($_FILES['gambar']['tmp_name'], "produk/".$_FILES['gambar']['name']);
				
				//hapus gambar
				if($move){
						$sql2 = "select * from produk where id_produk='".$_POST['ID']."'";  
					$result2 = mysql_query($sql2);  
					 if(mysql_num_rows($result2) > 0 ){  
					$data2 = mysql_fetch_array($result2);  
					//delete file  
					@unlink('produk/'.$data2['gambar']);
				}
				
					$update .= ", gambar='".$_FILES['gambar']['name']."'";
				}
			}
			$kdj=sha1($_POST['kat']);
			$update .= " where id_produk='".$_POST['ID']."'";
			mysql_query($update);
			echo"<script>";
			echo"alert('Data Produk Berhasil Diperbarui');";
			echo"window.location='?page=data_produk&idk=$kdj'";
			echo"</script>";
			exit;
		}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
#form1 table tr .tdat h2 {
	font-family: Harrington;
}
</style>
</head>

<body>
<?php
$ID=$_GET['idp'];

$qP=mysql_query("select * from produk where sha1(id_produk)='$ID'");
$dP=mysql_fetch_array($qP);
?>
<form action="" method="post" enctype="multipart/form-data" name="form1" id="form1">
  <table width="100%" border="0">
    <tr>
      <td class="tdat"><h2>Edit Produk
      </h2></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td><strong>Pilih Kategori Produk</strong></td>
    </tr>
    <tr>
      <td><label for="kat"></label>
        <select name="kat" id="kat">
        <?php
		$queryKat=mysql_query("select * from kategori_produk order by nama_kategori asc");
		while($dtKat=mysql_fetch_array($queryKat)){
			$idkat=sha1($dP['id_kategori']);
			if($dtKat['id_kategori']==$dP['id_kategori'])
			{
				$sl="selected";
			}
			else
			{
				$sl="";
			}
		?>
          <option value="<?php echo $dtKat['id_kategori'];?>" <?php echo $sl;?>><?php echo $dtKat['nama_kategori'];?></option>
          <?php } ?>
      </select></td>
    </tr>
    <tr>
      <td><strong>Nama Produk</strong></td>
    </tr>
    <tr>
      <td><label for="nama_produk"></label>
      <input name="nama_produk" type="text" required="required" id="nama_produk" placeholder="Masukkan Nama Produk" value="<?php echo $dP['nama_produk'];?>" size="30" maxlength="30" />
      <input name="ID" type="hidden" id="ID" value="<?php echo $dP['id_produk'];?>" /></td>
    </tr>
    <tr>
      <td><strong>Harga Produk</strong></td>
    </tr>
    <tr>
      <td><label for="harga_produk"></label>
      Rp. <input name="harga_produk" type="text" required="required" id="harga_produk" placeholder="99999" onkeypress="return harusangka(event)" value="<?php echo $dP['harga_produk'];?>" size="20" />,-</td>
    </tr>
    <tr>
      <td><strong>Deskripsi Produk</strong></td>
    </tr>
    <tr>
      <td><label for="deskripsi"></label>
      <textarea name="deskripsi" id="deskripsi" cols="60" rows="10" required="required" class="ckeditor"><?php echo $dP['keterangan'];?></textarea></td>
    </tr>
    <tr>
      <td><strong>Stok</strong></td>
    </tr>
    <tr>
      <td><label for="stok"></label>
      <input name="stok" type="text" required="required" id="stok" placeholder="999" onkeypress="return harusangka(event)" value="<?php echo $dP['stok'];?>" size="10" /></td>
    </tr>
    <tr>
      <td><strong>Berat Produk</strong></td>
    </tr>
    <tr>
      <td><label for="berat"></label>
      <input name="berat" type="text" id="berat" required="required" placeholder="9.9" size="10" value="<?php echo $dP['berat'];?>" /> 
      Kg <br />/*<strong>(Contoh Penulisan Berat : 2.5)</strong></td>
    </tr>
    <tr>
      <td><strong>Upload Gambar</strong></td>
    </tr>
    <tr>
      <td><img src="produk/<?php echo $dP['gambar'];?>" width="165" height="151" class="mg1" /></td>
    </tr>
    <tr>
      <td><label for="gambar"></label>
      <input type="file" name="gambar" id="gambar"/></td>
    </tr>
    <tr>
      <td><input type="submit" name="button" id="bttn" value="  Update  " />
      <a href="?page=data_produk&idk=<?php echo $idkat;?>" class="ahref"><input type="button" name="button2" id="bttn" value="  Batal  " /></a></td>
    </tr>
  </table>
</form>
<br />
</body>
</html>