<?php
$jumlah = count($_POST["item"]);
for($i=0; $i < $jumlah; $i++) 
{
	$ID=$_POST["item"][$i];
	$perintah=mysql_query("select * from galeri where id_galeri='$ID'");
	$dt=mysql_fetch_array($perintah);
	$foto=$dt['foto'];
	
	@unlink('../galeri/'.$foto);
	$sql="Delete from galeri where id_galeri='$ID'";
	$cek=mysql_query($sql);
}
?>
		<script language="javascript">
			alert("Data Dihapus");
			document.location="?page=galeri";
		</script>