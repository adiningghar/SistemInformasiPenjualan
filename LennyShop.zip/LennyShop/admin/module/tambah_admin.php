<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
#form1 table tr td strong {
	color: #636363;
	font-size: 12px;
	font-family: Arial, Helvetica, sans-serif;
}
#form1 table tr .tdat h2 {
	font-family: Harrington;
}
</style>
</head>

<body>
<form id="form1" name="form1" method="post" action="?page=simpan_admin">
  <table width="100%" border="0">
    <tr>
      <td class="tdat"><h2>Tambah Administrator</h2></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td><strong>Nama</strong></td>
    </tr>
    <tr>
      <td><strong>
      <input name="nama" type="text" id="nama" placeholder="Masukkan Nama Admin" required="required" size="30" maxlength="30" />
      </strong></td>
    </tr>
    <tr>
      <td><strong>Email</strong></td>
    </tr>
    <tr>
      <td><strong>
      <input name="email" type="text" id="email" size="40" maxlength="50" placeholder="Masukkan Email Admin" required="required" onchange="isEMailAddr(this)" />
      </strong></td>
    </tr>
    <tr>
      <td><strong>Password</strong></td>
    </tr>
    <tr>
      <td><strong>
      <input name="password" type="password" id="password" size="30" maxlength="30" placeholder="Masukkan Password" required="required" />
      </strong></td>
    </tr>
    <tr>
      <td><input type="submit" name="Submit" id="bttn" value="  Simpan  " />
      <input type="reset" name="button2" id="bttn" value="  Batal  " /></td>
    </tr>
  </table>
</form>
</body>
</html>