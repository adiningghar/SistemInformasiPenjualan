<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<form id="form1" name="form1" method="post" action="?page=eks_pass">
  <table width="98%" border="0" style="border: #EEE 1px solid; font-family: Harrington;">
    <tr>
      <td class="tdat"><h2>Buat Password Baru</h2></td>
    </tr>
  </table><br />
  <table width="98%" border="0">
    <tr>
      <td width="33%"><strong>Password Baru</strong></td>
      <td width="67%"><label for="pass"></label>
      <input name="pass" type="password" id="pass" size="30" maxlength="20" placeholder="Masukkan Password Baru" required />
      <input name="em" type="hidden" id="em" value="<?php echo $dtUser['email']; ?>" /></td>
    </tr>
    <tr>
      <td><strong>Konfirmasi Password Baru</strong></td>
      <td><label for="konf_pass"></label>
      <input name="konf_pass" type="password" id="konf_pass" size="30" maxlength="20" placeholder="Konfirmasi Password Baru" required /></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><input type="submit" name="button" id="bttn" value="  Submit  " /></td>
    </tr>
  </table>
</form>
</body>
</html>