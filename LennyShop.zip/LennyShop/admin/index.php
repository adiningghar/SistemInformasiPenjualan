<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Login Admin</title>
<link rel="shortcut icon" href="favicon.png" type="image/png"/>
<link rel="stylesheet" type="text/css" href="style.css" />
<script type="text/javascript">
// validates that the field value string has one or more characters in it
function isNotEmpty(elem) {
  var str = elem.value;
    var re = /.+/;
    if(!str.match(re)) {
        alert("Tesk Box Harap di isi.");
        setTimeout("focusElement('" + elem.form.name + "', '" + elem.name + "')", 0);
        return false;
    } else {
        return true;
    }
}
//validates that the entry is a positive or negative number
function isNumber(elem) {
  var str = elem.value;
    var re = /^[-]?\d*\.?\d*$/;
    str = str.toString();
    if (!str.match(re)) {
        alert("Enter only numbers into the field.");
        setTimeout("focusElement('" + elem.form.name + "', '" + elem.name + "')", 0);
        return false;
    }
    return true;
}
// validates that the entry is 16 characters long
function isLen16(elem) {
  var str = elem.value;
    var re = /\b.{16}\b/;
    if (!str.match(re)) {
        alert("Entry does not contain the required 16 characters.");
        setTimeout("focusElement('" + elem.form.name + "', '" + elem.name + "')", 0);
        return false;
    } else {
        return true;
    }
}
// validates that the entry is formatted as an e-mail address
function isEMailAddr(elem) {
  var str = elem.value;
    var re = /^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$/;
    if (!str.match(re)) {
        alert("Penulisan alamat e-mail salah.");
        setTimeout("focusElement('" + elem.form.name + "', '" + elem.name + "')", 0);
        return false;
    } else {
        return true;
    }
}
// validate that the user made a selection other than default
function isChosen(select) {
    if (select.selectedIndex == 0) {
        alert("Please make a choice from the list.");
        return false;
    } else {
        return true;
    }
}

// validate that the user has checked one of the radio buttons
function isValidRadio(radio) {
    var valid = false;
    for (var i = 0; i < radio.length; i++) {
        if (radio[i].checked) {
            return true;
        }
    }
    alert("Make a choice from the radio buttons.");
    return false;
}

function focusElement(formName, elemName) {
    var elem = document.forms[formName].elements[elemName];
    elem.focus();
    elem.select();
}

// batch validation router
function validateForm(form) {
    if (isNotEmpty(form.nama)) {
            if (isNotEmpty(form.email)) {
                if (isEMailAddr(form.email)) {
					if (isNotEmpty(form.pass)) {
						if (isNotEmpty(form.konf_pass)) {
									if (isNotEmpty(form.alamat)) {
                    					if (isNotEmpty(form.telp)) {
                            					return true;
										}
									}
                        }
                    }
                }
            }
    }
    return false;
}
function harusangka(jumlah){
  var karakter = (jumlah.which) ? jumlah.which : event.keyCode
  if (karakter > 31 && (karakter < 48 || karakter > 57))
    return false;

  return true;
}
</script>
</head>

<body>
<form id="form1" name="form1" method="post" action="cek_login.php">
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <table width="25%" border="0" bgcolor="transparent" align="center" style="border: solid 0px #FF679A; color: #FF679A; ">
  <tr>
      <td><img src="../images/lens_logo.png" width="300" height="147" /></td>
    </tr>
</table>
<br />
  <table width="25%" border="0" bgcolor="transparent" align="center" style="border: solid 1px #FF679A; color: #FF679A; font-family: Arial, Helvetica, sans-serif; font-size: 12px;">
    <tr>
      <td bgcolor="#FF679A" style="color:#FFF;" align="center"><h2>Login Administrator</h2></td>
    </tr>
    <tr>
      <td><strong>Email Administrator</strong></td>
    </tr>
    <tr>
      <td><label for="email"></label>
      <input name="email" type="text" id="email" size="40" maxlength="50" placeholder="Masukkan Email Anda" required="required" onchange="isEMailAddr(this)" /></td>
    </tr>
    <tr>
      <td><strong>Password</strong></td>
    </tr>
    <tr>
      <td><label for="pass"></label>
      <input name="pass" type="password" id="pass" size="40" maxlength="20" placeholder="Masukkan Password" required="required" /></td>
    </tr>
    <tr>
      <td><input type="submit" name="button" id="bttn" value="  Login  " /></td>
    </tr>
    
  </table>
</form>
</body>
</html>