<?php
include "../koneksi/koneksi.php";
include "cek_session_admin.php";

$showUser=mysql_query("select * from admin where email='".$_SESSION['idadmin']."'");
$dtUser=mysql_fetch_array($showUser);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Len's Accessories</title>
<link rel="stylesheet" type="text/css" href="style.css" />
<link rel="stylesheet" href="flexslider.css" type="text/css" />
<link href="SpryAssets/SpryMenuBarVertical.css" rel="stylesheet" type="text/css" />
<link rel="shortcut icon" href="favicon.png" type="image/png"/>
<style type="text/css">
a:hover {
	color: #FF0657;
}
</style>
<script type="text/javascript"  src="js/jquery-1.8.2.min.js"></script>
	<script src="js/custom.js"></script>
	<script src="js/selectnav.js"></script>
    <script src="../Scripts/ckeditor.js"></script>
	<script type="text/javascript"  src="js/jquery.flexslider.js"></script>
	<script src="SpryAssets/SpryMenuBar.js" type="text/javascript"></script>
	<script type="text/javascript">
	$(window).load(function() {
		$('.flexslider').flexslider({
			animation: "slide"
		});
	});
	</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="js/jquery.colorbox.js"></script>
<script type="text/javascript">
// validates that the field value string has one or more characters in it
function isNotEmpty(elem) {
  var str = elem.value;
    var re = /.+/;
    if(!str.match(re)) {
        alert("Tesk Box Harap di isi.");
        setTimeout("focusElement('" + elem.form.name + "', '" + elem.name + "')", 0);
        return false;
    } else {
        return true;
    }
}
//validates that the entry is a positive or negative number
function isNumber(elem) {
  var str = elem.value;
    var re = /^[-]?\d*\.?\d*$/;
    str = str.toString();
    if (!str.match(re)) {
        alert("Enter only numbers into the field.");
        setTimeout("focusElement('" + elem.form.name + "', '" + elem.name + "')", 0);
        return false;
    }
    return true;
}
// validates that the entry is 16 characters long
function isLen16(elem) {
  var str = elem.value;
    var re = /\b.{16}\b/;
    if (!str.match(re)) {
        alert("Entry does not contain the required 16 characters.");
        setTimeout("focusElement('" + elem.form.name + "', '" + elem.name + "')", 0);
        return false;
    } else {
        return true;
    }
}
// validates that the entry is formatted as an e-mail address
function isEMailAddr(elem) {
  var str = elem.value;
    var re = /^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$/;
    if (!str.match(re)) {
        alert("Penulisan alamat e-mail salah.");
        setTimeout("focusElement('" + elem.form.name + "', '" + elem.name + "')", 0);
        return false;
    } else {
        return true;
    }
}
// validate that the user made a selection other than default
function isChosen(select) {
    if (select.selectedIndex == 0) {
        alert("Please make a choice from the list.");
        return false;
    } else {
        return true;
    }
}

// validate that the user has checked one of the radio buttons
function isValidRadio(radio) {
    var valid = false;
    for (var i = 0; i < radio.length; i++) {
        if (radio[i].checked) {
            return true;
        }
    }
    alert("Make a choice from the radio buttons.");
    return false;
}

function focusElement(formName, elemName) {
    var elem = document.forms[formName].elements[elemName];
    elem.focus();
    elem.select();
}

// batch validation router
function validateForm(form) {
    if (isNotEmpty(form.nama)) {
            if (isNotEmpty(form.email)) {
                if (isEMailAddr(form.email)) {
					if (isNotEmpty(form.pass)) {
						if (isNotEmpty(form.konf_pass)) {
									if (isNotEmpty(form.alamat)) {
                    					if (isNotEmpty(form.telp)) {
                            					return true;
										}
									}
                        }
                    }
                }
            }
    }
    return false;
}
function harusangka(jumlah){
  var karakter = (jumlah.which) ? jumlah.which : event.keyCode
  if (karakter > 31 && (karakter < 48 || karakter > 57))
    return false;

  return true;
}
</script>
</head>

<body>
<div id="outer-top">
<div class="clear"></div>
  <div id="header"><!--<img src="../images/logoatas.png" width="1000" height="150" />--></div>
</div>
<div class="clear"></div>
<div id="login"><strong>Selamat Datang <?php echo $dtUser['nama'];?> | <a href="?page=ganti_password">Ganti Password</a> | <a href="?page=logout">Logout</a></strong></div>
<div id="outer-content">
	<div id="content">
    	<div id="bilah-kiri">
          <ul id="MenuBar1" class="MenuBarVertical">
            <li><a href="beranda_admin.php">Beranda</a>            </li>
            <li><a href="?page=buku_tamu">Buku Tamu</a></li>
            <li><a href="?page=data_member">Data Member</a></li>
            <li><a href="#" class="MenuBarItemSubmenu">Administrator</a>
              <ul>
                <li><a href="?page=data_admin">Data Administrator</a></li>
                <li><a href="?page=tambah_admin">Tambah Administrator</a></li>
              </ul>
            </li>
            <li><a class="MenuBarItemSubmenu" href="#">Kategori Produk</a>
              <ul>
                <li><a href="?page=data_kategori">Data Kategori Produk</a></li>
                <li><a href="?page=tambah_kategori">Tambah Kategori Produk</a></li>
              </ul>
            </li>
            <li><a href="#" class="MenuBarItemSubmenu">Produk</a>
              <ul>
                <li><a href="#" class="MenuBarItemSubmenu">Data Produk</a>
                  <ul>
                  <?php
				  $qk=mysql_query("select * from kategori_produk order by nama_kategori asc");
				  while($rK=mysql_fetch_array($qk)){
				  ?>
                    <li><a href="?page=data_produk&idk=<?php echo sha1($rK['id_kategori']);?>"><?php echo $rK['nama_kategori'];?></a></li>
                  <?php } ?>
                  </ul>
                </li>
                <li><a href="?page=tambah_produk">Tambah Produk</a></li>
              </ul>
            </li>
            <li><a href="#" class="MenuBarItemSubmenu">Ongkos Kirim</a>
              <ul>
                <li><a href="?page=data_ongkir">Data Ongkos Kirim</a></li>
                <li><a href="?page=input_ongkir">Input Ongkos Kirim</a></li>
              </ul>
            </li>
            <li><a href="#" class="MenuBarItemSubmenu">Informasi</a>
              <ul>
                <li><a href="?page=data_informasi">Data Informasi</a></li>
                <li><a href="?page=input_informasi">Tambah Informasi</a></li>
              </ul>
            </li>
            <li><a href="#" class="MenuBarItemSubmenu">Slide Show</a>
              <ul>
                <li><a href="?page=tambah_galeri">Tambah Galeri</a></li>
                <li><a href="?page=galeri">Data Galeri</a></li>
              </ul>
            </li>
            <li><a href="?page=data_pesanan">Data Order Masuk</a></li>
            <li><a href="?page=data_konfirmasi">Data Konfirmasi Bayar</a></li>
            <li><a href="?page=laporan_barang_terjual">Laporan Penjualan</a></li>
            </li>
          </ul>
      </div>
        
        <div id="content-isi">
        <?php
		 error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
	  		$page=mysql_real_escape_string(htmlentities($_GET['page']));
	  		$file='module/'.$page.'.php';
	  
	  		if(!file_exists($file) || empty($page))
	  		{
		  		include 'module/beranda.php';
	  		}
	  		else
	  		{
		  		include 'module/'.$page.'.php';
	  		}
			
	  ?>
        </div>
      <div class="clear"></div>
    </div>
</div>
<div class="clear"></div>
<div id="outer-footer">
<div id="footer">
<p align="center">&copy;2015 Len's Accessories - All Rights Reserved</p>
</div>
</div>
<script type="text/javascript">
var MenuBar1 = new Spry.Widget.MenuBar("MenuBar1", {imgRight:"SpryAssets/SpryMenuBarRightHover.gif"});
</script>
</body>
</html>