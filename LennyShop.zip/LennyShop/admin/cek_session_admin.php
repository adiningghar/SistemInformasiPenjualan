<?php  
session_start();

if(!isset($_SESSION['admin']) || ($_SESSION['admin']!=md5($_SESSION['idadmin'])) )
{
	?><script language="javascript">
	alert("Maaf, Anda tidak berhak mengakses halaman ini!!");
	document.location="../index.php";
	</script>
	<?php 
}
?>