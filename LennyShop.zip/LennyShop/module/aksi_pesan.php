<?php
include"cek_session.php";
session_start();
	function isi_keranjang (){
		$isikeranjang = array ();

		$sql = mysql_query ("SELECT * FROM keranjang where no_trans='".$_SESSION['transaksi']."'");
		while ($r=mysql_fetch_array($sql)) {
		$isikeranjang [] = $r;
		}
		return $isikeranjang;
	}

$user=$_POST['id_member'];
$email=$_POST['email'];
$id_ong=$_POST['kota'];
$cekOngkir=mysql_query("select * from ongkir where id_ongkir='$id_ong'");
$dtOngkir=mysql_fetch_array($cekOngkir);
$ongkir=$dtOngkir['ongkir'];

$alamat=$_POST['alamat'];
$ket='Pesan';
$waktu= date("H:i:s");
$kode=$_SESSION['transaksi'];

$isikeranjang = isi_keranjang();
$jml = count($isikeranjang);

for ($i = 0; $i < $jml; $i++) {
	$a=$isikeranjang[$i]['no_trans'];
	$b=$isikeranjang[$i]['id_produk'];
	$c=$isikeranjang[$i]['jumbel'];
	
	$d=mysql_query("select * from produk where id_produk='$b'");
	$e=mysql_fetch_array($d);
	$f=$e['stok'];
	$h=$e['harga_produk'];
	$brt=$e['berat']*$c;
	$sub=$sub + ($h * $c);
	$sub_qty=$sub_qty+$brt;
	$g=$f-$c;
	$bv=$e['dibeli'];
	$cv=$bv+1;
	
	mysql_query("INSERT INTO detail_pesanan VALUES (NOW(),'$a','$b','$h','$c')") or die("QUERY GAGAL");
	$update_brg=mysql_query("update produk set stok='$g', dibeli='$cv' where id_produk='$b'");
}
$ong=$sub_qty*$ongkir;

$pesan = mysql_query("INSERT INTO pesanan VALUES ('".$_SESSION['transaksi']."','$email','$ket',NOW(),'$waktu','$sub','$alamat','$ong')");

mysql_query("DELETE FROM keranjang WHERE no_trans='".$_SESSION['transaksi']."'");

unset($_SESSION['transaksi']);
echo'<script>';
echo"window.location='beranda_member.php?page=struk&no=$kode'";
echo'</script> ';

?>