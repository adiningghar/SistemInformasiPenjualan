<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Len's Accessories</title>
<link rel="shortcut icon" href="../images/favicon.png" type="image/png"/>
<style type="text/css">
#content-2-atas table tr table tr td strong {
	color: #ff679a;
}
</style>
<script type="text/javascript"  src="js/jquery-1.8.2.min.js"></script>
	<script src="js/custom.js"></script>
	<script src="js/selectnav.js"></script>
	<script type="text/javascript"  src="js/jquery.flexslider.js"></script>
	<script type="text/javascript">
	$(window).load(function() {
		$('.flexslider').flexslider({
			animation: "slide"
		});
	});
	</script>
</head>

<body>
<div id="content-2-atas">
		<div class="container">
			<div class="sixteen columns">
				<div id="slider">
					<div class="flexslider">
					  <ul class="slides">
                      <?php
					  $qG=mysql_query("select * from galeri order by id_galeri desc");
					  while($dtG=mysql_fetch_array($qG)){
					  ?>
							<li>
								<img src="galeri/<?php echo $dtG['foto'];?>" width="790" height="300" />
							</li>
                            <?php } ?>
						</ul>
					</div>
				</div>
			</div>
		</div> 
	</div>
    <div class="clear"></div>
    <div id="content-2-atas">
      <?php
		$strSQL = "SELECT * FROM produk order by id_produk desc";
		
                            $objQuery = mysql_query($strSQL);
                    		?>
                    		<table width="100%" align="center" border="0" style="border:solid 1px #EEE;">
                            <tr>
                            <td background="images/detail.jpg"  style="color:#FFF;"><h2 style="margin:0; padding:0;">&nbsp;Produk Terbaru</h2></td>
                            </tr>
                            </table>
                            
                            <table  cellspacing="10" cellpadding="10" align="center" style="font-size:12px; font-family: Arial, Helvetica, sans-serif;">
                            <tr>
								<?
                                $intRows = 0;
								for($i=1; $i<=12; $i++)
								{
                                $objResult = mysql_fetch_array($objQuery);
                                    echo "<td  valign='top'>"; 
                                    $intRows++;
                            	?>
                                    <table style="border: solid 1px #EEE; -webkit-border-radius: 5px; -moz-border-radius: 5px; border-radius: 5px; color: #904A95;">
                                        <tr>
                                        	<td align="center" colspan="2"><a class="group3" href="?page=detail_produk&id=<?=sha1($objResult["id_produk"]);?>" title="<?=$objResult["nama_produk"];?>"><img src="admin/produk/<?=$objResult["gambar"];?>" width="120" height="120" style="-webkit-border-radius: 10px; -moz-border-radius: 10px; border-radius: 10px; padding:5px"></a></td>
                                        </tr>
                                        <?php  
										if($objResult['stok']<=0)
										$ket="<strong><font color='#FF0000'>SOLD OUT!</font></strong>";
										else
										$ket="<strong><font color='#904A95'>READY STOCK!</font></strong>";
										$IDB=sha1($objResult['id_produk']);
										if(!isset($_SESSION['member']) || ($_SESSION['member']!=md5($_SESSION['idmember'])) )
										{
											if($objResult['stok']<=0)
											{
												$almt="#";
											}
											else
											{
												$confirm="
												alert('Untuk Melakukan Transaksi Anda Harus Login Sebagai Member');
												return confirm('Belum Menjadi Member? Silahkan Daftar Terlebih Dahulu!');";
												$almt="?page=daftar";
											}
										}
										else
										{
											if($objResult['stok']<=0)
											{
												$almt="#";
											}
											else
											{
												$almt="?page=simpan_keranjang&id=$IDB";
											}
										}
										?>
                                                                                <tr>
                                        	<td align="center"><strong><?=$objResult["nama_produk"];?></strong></td>
                                        </tr>
                                        <tr>
                                        	<td align="center">Rp. <?=$objResult["harga_produk"];?>,-</td>
                                        </tr>
                                        <tr>
                                        	<td align="center"><strong><a href="?page=detail_produk&id=<?=sha1($objResult["id_produk"]);?>" class="ahref"><img src="images/icon_detail_data.png" width="15" height="10" />Detail</a> | <a href="<?php echo $almt;?>" class="ahref" onclick="<?php echo $confirm;?>"><img src="images/Logo Keranjang Belanja 1.jpg" width="15" height="10" />Buy</a></strong></td>
                                        </tr>
                                   </table>
                            	<?
                                    echo"</td>";
                                    if(($intRows)%4==0)
                                    {
                                        echo"</tr>";
                                    }
                                }
                           		?>
                        		</tr>
                                </table><br /><br />
                                <?php
		$strSQL1 = "SELECT * FROM produk order by dibeli desc";
		
                            $objQuery1 = mysql_query($strSQL1);
                    		?>
                    		<table width="100%" align="center" border="0" style="border:solid 1px #EEE;">
                            <tr>
                            <td background="images/detail.jpg" style="color:#FFF; font-family:Arial, Helvetica, sans-serif;"><h2 style="margin:0; padding:0;">&nbsp;Produk Terlaris</h2></td>
                            </tr>
                            </table>
                            
                            <table  cellspacing="10" cellpadding="10" align="center" style="font-size:12px; font-family: Arial, Helvetica, sans-serif;">
                            <tr>
								<?
                                $intRows1 = 0;
								for($i1=1; $i1<=4; $i1++)
								{
                                $objResult1 = mysql_fetch_array($objQuery1);
                                    echo "<td  valign='top'>"; 
                                    $intRows1++;
                            	?>
                                    <table style="border: solid 1px #EEE; -webkit-border-radius: 5px; -moz-border-radius: 5px; border-radius: 5px; color: #904A95;">
                                        <tr>
                                        	<td align="center" colspan="2"><a class="group3" href="?page=detail_produk&id=<?=sha1($objResult1["id_produk"]);?>" title="<?=$objResult1["nama_produk"];?>"><img src="admin/produk/<?=$objResult1["gambar"];?>" width="120" height="120" style="-webkit-border-radius: 10px; -moz-border-radius: 10px; border-radius: 10px; padding:5px"></a></td>
                                        </tr>
                                        <?php  
										if($objResult1['stok']<=0)
										$ket1="<strong><font color='#FF0000'>SOLD OUT!</font></strong>";
										else
										$ket1="<strong><font color='#904A95'>READY STOCK!</font></strong>";
										$IDB1=sha1($objResult1['id_produk']);
										if(!isset($_SESSION['member']) || ($_SESSION['member']!=md5($_SESSION['idmember'])) )
										{
											if($objResult1['stok']<=0)
											{
												$almt1="#";
											}
											else
											{
												$confirm1="
												alert('Untuk Melakukan Transaksi Anda Harus Login Sebagai Member');
												return confirm('Belum Menjadi Member? Silahkan Daftar Terlebih Dahulu!');";
												$almt1="?page=daftar";
											}
										}
										else
										{
											if($objResult1['stok']<=0)
											{
												$almt1="#";
											}
											else
											{
												$almt1="?page=simpan_keranjang&id=$IDB1";
											}
										}
										?>
                                                                                <tr>
                                        	<td align="center"><strong><?=$objResult1["nama_produk"];?></strong></td>
                                        </tr>
                                        <tr>
                                        	<td align="center">Rp. <?=$objResult1["harga_produk"];?>,-</td>
                                        </tr>
                                        <tr>
                                        	<td align="center"><strong><a href="?page=detail_produk&id=<?=sha1($objResult1["id_produk"]);?>" class="ahref"><img src="images/icon_detail_data.png" width="15" height="10" />Detail</a> | <a href="<?php echo $almt1;?>" class="ahref" onclick="<?php echo $confirm1;?>"><img src="images/Logo Keranjang Belanja 1.jpg" width="15" height="10" />Beli</a></strong></td>
                                        </tr>
                                   </table>
                            	<?
                                    echo"</td>";
                                    if(($intRows1)%4==0)
                                    {
                                        echo"</tr>";
                                    }
                                }
                           		?>
                        		</tr>
                                </table>
                                </div>
</body>
</html>