<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<div id="content-2-bawah">
<table width="100%" border="0" align="center" style="border:solid 1px #EEE;">
  <tr>
    <td background="images/detail.jpg" style="color: #FFF; font-family: Harrington;"><h2>&nbsp;Detail History Order</h2></td>
  </tr>
</table>
<?php
$no_trans=$_GET['no'];
$qPesan=mysql_query("select * from pesanan where no_trans='$no_trans'");
$rPesan=mysql_fetch_array($qPesan);
$email=$rPesan['email'];

$pmsn=mysql_query("select * from member where email='$email'");
$dtPmsn=mysql_fetch_array($pmsn);
?>
<table width="100%" border="0" align="center">
  <tr>
    <td><strong>Nomor Transaksi</strong></td>
    <td width="74%" colspan="3"><?php echo $rPesan['no_trans'];?></td>
  </tr>
  <tr>
    <td><strong>Tgl/waktu</strong></td>
    <td colspan="3"><?php echo $rPesan['tgl_order'];?>/<?php echo $rPesan['jam_order'];?></td>
  </tr>
  <tr>
    <td><strong>Nama Pemesan</strong></td>
    <td colspan="3"><?php echo $dtPmsn['nama'];?></td>
  </tr>
  <tr>
    <td><strong>Alamat Pengiriman</strong></td>
    <td colspan="3"><?php echo $rPesan['alamat_pengiriman'];?></td>
  </tr>
  <tr>
    <td colspan="5">&nbsp;</td>
  </tr>
  </table>
  <table width="100%" border="0" align="center" class="tabel2">
  <tr>
    <td width="4%"><strong>No.</strong></td>
    <td width="32%"><strong>Nama Produk</strong></td>
    <td width="21%"><strong>Harga Produk</strong></td>
    <td width="19%"><strong>Jumlah Beli</strong></td>
    <td width="19%"><strong>Subtotal</strong></td>
  </tr>
  <?php
  $qDP=mysql_query("select * from detail_pesanan where no_trans='$no_trans'");
  while($rDP=mysql_fetch_array($qDP)){
	  $idp=$rDP['id_produk'];
	  $qBrg=mysql_query("select * from produk where id_produk='$idp'");
	  $dBrg=mysql_fetch_array($qBrg);
	  $sub=$rDP['harga_produk']*$rDP['jumbel'];
  ?>
  <tr>
    <td><?php
	  		error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
	 echo $no=$no+1;?></td>
    <td><?php echo $dBrg['nama_produk'];?></td>
    <td>Rp. <?php echo $rDP['harga_produk'];?>,-</td>
    <td><?php echo $rDP['jumbel'];?></td>
    <td>Rp. <?php echo $sub;?>,-</td>
  </tr>
  <?php } ?>
  <tr>
    <td colspan="4" align="center"><strong>Ongkos Kirim</strong></td>
    <td>Rp. <?php echo $rPesan['ongkir'];?>,-</td>
  </tr>
  <tr>
    <td colspan="4" align="center"><strong>Total Bayar</strong></td>
    <td>Rp. <?php echo $tot=$rPesan['total']+$rPesan['ongkir'];?>,-</td>
  </tr>
  <tr>
    <td colspan="5"><strong>NB : WAJIB Cetak struk ini dan segera lakukan transfer sesuai dengan total bayar yang tertera.</strong></td>
  </tr>
</table>
<br />
<table width="98%" border="0" align="center">
  <tr>
    <td align="center"><a href="module/cetak_struk.php?no=<?php echo $no_trans;?>" target="_blank" class="ahref"><strong>Klik Untuk Cetak</strong></a></td>
  </tr>
</table>
</div>
</body>
</html>