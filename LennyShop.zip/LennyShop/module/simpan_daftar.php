<?php
session_start();
$nama=$_POST['nama'];
$alamat=$_POST['alamat'];
$telp=$_POST['telp'];
$email=$_POST['email'];
$pass=sha1($_POST['pass']);
$konf_pass=sha1($_POST['konf_pass']);
$kode=$_POST['kode'];

if($kode!=$_SESSION['kode_cap'])
{
	?>
    <script language="javascript">
      alert("Kode Tidak sesuai");
      history.go(-1);
	</script>
    <?php
}
else
{
if($pass!=$konf_pass)
{
	?>
    <script>
	alert("Pendaftaran GAGAL, Password dan Konfirmasi Password Tidak Sama");
	history.go(-1);
	</script>
    <?php
}
else
{
	$simpan=mysql_query("insert into member values('$email','$pass','$nama','$alamat','$telp')");
	if($simpan)
	{
		error_reporting(0);
		session_start();
		$_SESSION['idmember']=$email;
		$_SESSION['member']=md5($_SESSION['idmember']);
		?>
		<script>
			alert('Pendaftaran Sukses! Silahkan Lanjutkan Belanja');
			window.location="beranda_member.php";
		</script>
    	<?php
	}
	else
	{
		?>
        <script>
		alert("Pendaftaran GAGAL, Email yang Anda Pakai Sudah Terdaftar!");
		history.go(-1);
		</script>
        <?php
	}
}
}
?>