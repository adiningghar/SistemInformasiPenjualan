<?php
function cek_pesan($teks)
{
$kata_kotor = array("anjing","dancuk","bajingan","tolol","bodoh","asu","kontol","tai","memek","bangsat","fuck","goblok","babi");
$hasil = 0;
$jml_kata = count($kata_kotor);
for ($i=0;$i<$jml_kata;$i++)
{
if (stristr($teks,$kata_kotor[$i]))
{ $hasil=1; }
} 
return $hasil; 
}

$nama=$_POST['nama'];
$email=$_POST['email'];
$pesan=$_POST['pesan'];

if (cek_pesan($pesan))
{
	?>
    <script>
	alert("Pesan/Kesan Gagal Disimpan");
	history.go(-1);
	</script>
    <?php
}
else
{
$simpan=mysql_query("insert into buku_tamu values('','$nama','$email','$pesan',NOW(),'No')");
if($simpan)
{
	?>
    <script>
	alert("Terima Kasih Atas Pesan yang Sudah Anda Sampaikan");
	document.location='?page=buku_tamu';
	</script>
    <?php
}
else
{
	?>
    <script>
	alert("Maaf Pesan Gagal Dikirim!!");
	document.location='?page=buku_tamu';
	</script>
    <?php
}
}
?>