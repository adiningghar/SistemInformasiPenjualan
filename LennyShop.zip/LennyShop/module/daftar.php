<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
#content-2-bawah form table tr td strong {
	color: #636363;
	font-size: 12px;
	font-family: Arial, Helvetica, sans-serif;
}
</style>
</head>

<body>
<div id="content-2-bawah">
<form action="?page=simpan_daftar" method="post" onsubmit="return validateForm(this)">
<table width="100%" border="0" align="center" style="border:solid 1px #EEE;">
  <tr valign="top" bgcolor="#EEE">
    <td colspan="3" bgcolor="#904A95" style="color:#FFF;"><h2>&nbsp;Daftar Akun Baru</h2></td>
  </tr>
  </table>
 <table width="100%" border="0" align="center">
  <tr valign="top">
    <td width="18%"><strong>Nama Lengkap</strong></td>
    <td width="80%"><label for="nama"></label>
      <input name="nama" type="text" id="nama" size="30" maxlength="30" placeholder="Nama Lengkap Anda" required="required" /></td>
  </tr>
  <tr valign="top">
    <td><strong>Alamat Lengkap</strong></td>
    <td><label for="alamat"></label>
      <textarea name="alamat" id="alamat" cols="50" rows="5" placeholder="Masukkan Alamat Lengkap Anda" required="required"></textarea></td>
  </tr>
  <tr valign="top">
    <td><strong>Nomor Telepon</strong></td>
    <td><label for="telp"></label>
      <input name="telp" type="text" id="telp" size="20" maxlength="12" placeholder="No. Telp/Hp." onkeypress="return harusangka(event)" required="required" /></td>
  </tr>
  <tr valign="top">
    <td><strong>Email</strong></td>
    <td><label for="email"></label>
      <input name="email" type="text" id="email" size="40" maxlength="50" placeholder="Masukkan Email Anda" required="required" onchange="isEMailAddr(this)" /></td>
  </tr>
  <tr valign="top">
    <td><strong>Kata Sandi</strong></td>
    <td><label for="pass"></label>
      <input name="pass" type="password" id="pass" size="20" maxlength="12" placeholder="Password" required="required" /></td>
  </tr>
  <tr valign="top">
    <td><strong>Ulangi Kata Sandi</strong></td>
    <td><label for="konf_pass"></label>
      <input name="konf_pass" type="password" id="konf_pass" size="20" maxlength="12" placeholder="Konf. Password" required="required" /></td>
  </tr>
  <tr valign="top">
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <?php 
	$text = rand(100000,999999);
	$_SESSION["kode_cap"] = $text;
	
	$path = "images/captcha/";
	$ext = ".png";
	
	$text = sprintf("%06d", $text);
	for ( $i = 0; $i <= 9; $i++ ){
		$text = str_replace($i, "<img src='$path$i$ext' alt='$i'>", $text);
	}
	
	?>
  <tr valign="top">
    <td>&nbsp;</td>
    <td><?php echo "$text";?></td>
  </tr>
  <tr valign="top">
    <td>&nbsp;</td>
    <td><label for="kode"></label>
      <input type="text" name="kode" id="kode" required="required" placeholder="Masukkan Kode" /></td>
  </tr>
  <tr valign="top">
    <td>&nbsp;</td>
    <td><input type="submit" name="button" id="bttn" value="  Daftar  " />
      <input type="reset" name="button2" id="bttn" value="  Batalkan  " /></td>
  </tr>
</table>
</form>
<br />
</div>
</body>
</html>