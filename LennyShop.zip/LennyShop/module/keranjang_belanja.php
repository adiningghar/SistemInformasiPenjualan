<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<style type="text/css">
#content-2-bawah .tabel2 tr td strong {
	color: #ffffff;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 14px;
}
#content-2-bawah table tr td strong {
	color: #636363;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 14px;
}
#content-2-bawah table tr td {
	font-size: 12px;
}
</style>
</head>

<body>
<div id="content-2-bawah">
<table width="100%" border="0" align="center" style="border:solid 1px #EEE;">
  <tr bgcolor="#EEE">
    <td background="images/detail.jpg" style="color: #FFF; font-family: Harrington;"><h2>&nbsp;Keranjang Belanja</h2></td>
  </tr>
</table>
<table width="100%" border="0" align="center" class="tabel2">
  <tr align="center">
    <td background="images/detail.jpg" width="7%"><strong>Gambar</strong></td>
    <td background="images/detail.jpg" width="26%"><strong>Nama Produk</strong></td>
    <td background="images/detail.jpg" width="18%"><strong>Harga</strong></td>
    <td background="images/detail.jpg" width="10%"><strong>Jumlah Beli</strong></td>
    <td background="images/detail.jpg" width="17%"><strong>Subtotal</strong></td>
    <td background="images/detail.jpg" colspan="2"><strong>Opsi</strong></td>
  </tr>
  <?php
$k = mysql_query("select * from keranjang where email='".$_SESSION['idmember']."'");
	while($row=mysql_fetch_array($k)){
		$kdp=$row['id_produk'];
		$b = mysql_query("select * from produk where id_produk='$kdp'");
		while($row2=mysql_fetch_array($b))
			{
				$subttl=$row2['harga_produk']*$row['jumbel'];
?>
	<form action="?page=aksi_keranjang" method="post">
  <tr>
    <td align="center"><img src="admin/produk/<?php echo $row2["gambar"];?>" width="50" height="50" style="-webkit-border-radius: 10px; -moz-border-radius: 10px; border-radius: 10px; padding:5px"></td>
    <td><?php echo $row2['nama_produk'];?><input name="idbrg" type="hidden" id="idbrg" value="<?php echo $row2['id_produk'];?>" /></td>
    <td>Rp. <?php echo $row2['harga_produk'];?></td>
    <td><input name="jumlah" type="text" style="text-align:center" value="<?php echo $row['jumbel'];?>" size="5" /></td>
    <td>Rp. <?php echo $subttl;?></td>
    <td width="11%" align="center"><input type="hidden" name="aksi" value="ubah" /><input type="hidden" name="id" value="<?php echo $row['id_keranjang'];?>" /><input name="Submit" type="submit" id="bttn" value="  Ubah  " /></td>
    <td width="11%" align="center"><a href="?page=aksi_keranjang&aksii=hapus&idt=<?php echo $row['id_keranjang'];?>" style="width:30px; height:30px" class=" nongaris"><input type="button" id="bttn" value="  Batal  " /></a></td>
  </tr>
  </form>

  <?php
    		error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));

	$total=$subttl+$total;
	}
	}
?>
  <tr>
  </table>
  <?php
  $cek_keranjang=mysql_query("select COUNT(*) as jumData from keranjang where email='".$_SESSION['idmember']."'");
  $dt=mysql_fetch_array($cek_keranjang);
  $jumKeranjang=$dt['jumData'];
  
  if($jumKeranjang>0)
  {
	  $idk=$_SESSION['transaksi'];
	  $almt="<a href='?page=konfirmasi_pesan&id=$idk' style='width:100px; height:30px; color:#FFF' class='ahref'>";
	  $label="  Selesai Belanja  ";
  }
  else
  {
	  $almt="<a href='?page=produk' style='width:100px; height:30px; color:#FFF' class='ahref'>";
	  $label="  Kembali Ke Produk  ";
  }
  ?><br />
  <table width="100%" border="0">
    <td colspan="4" align="center"><strong>Total Belanja</strong></td>
    <td width="57%">Rp. <?php   		
	error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
	echo $total;?></td>
    <td width="22%" colspan="2" align="center"><?php echo $almt;?><input type="button" id="bttn" value="<?php echo $label;?>" /></a></td>
  </tr>
</table></div>
</body>
</html>