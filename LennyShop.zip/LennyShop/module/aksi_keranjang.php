<?php
include"cek_session.php";
$aksi=$_POST['aksi'];
$aksi1=$_GET['aksii'];
$IDT=$_POST['id'];
$jumlah=$_POST['jumlah'];
$idb=$_POST['idbrg'];
$ID=$_GET['idt'];
if($aksi=="ubah")
{
	$sqlStok=mysql_query("select * from produk where id_produk='$idb'");
	$queryStok=mysql_fetch_array($sqlStok);
	$jumStok=$queryStok['stok'];
	if($jumStok<$jumlah)
	{
		?>
        <script>
		alert("Stok Kurang");
		document.location='beranda_member.php?page=keranjang_belanja';
		</script>
        <?php
	}
	else
	{
	$query = mysql_query("update keranjang set jumbel='$jumlah' where id_keranjang='$IDT'") or die(mysql_error());
	if ($query){
		echo"<script>";
		echo'window.location="beranda_member.php?page=keranjang_belanja"';
		echo"</script>";
	}	
	}
}
elseif($aksi1=="hapus")
{
	$query2 = mysql_query("delete from keranjang where id_keranjang='$ID'") or die(mysql_error());

	if ($query2) {
		echo"<script>";
		echo'window.location="beranda_member.php?page=keranjang_belanja"';
		echo"</script>";
		}
}
?>