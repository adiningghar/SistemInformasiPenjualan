<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
#content-2-bawah table tr td strong {
	color: #333333;
	font-size: 12px;
	font-family: Arial, Helvetica, sans-serif;
}
#content-2-bawah table tr td .ahref {
	font-weight: bold;
}
</style>
</head>

<body>
<div id="content-2-bawah">
<table width="100%" border="0" align="center" style="border:solid 1px #EEE;">
  <tr>
    <td background="images/detail.jpg" style="color: #FFF; font-family: Harrington;"><h2>&nbsp;History Order</h2></td>
  </tr>
</table>
<table width="100%" border="0" align="center" >
  <tr>
    <td><strong>No.</strong></td>
    <td><strong>Nomor Transaksi</strong></td>
    <td><strong>Tanggal Transaksi</strong></td>
    <td><strong>Status Order</strong></td>
    <td><strong>Opsi</strong></td>
  </tr>
   <?php
     		error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));

	$strSQL = "SELECT * FROM pesanan";
    $objQuery = mysql_query($strSQL);
    $Num_Rows = mysql_num_rows($objQuery);
                    
    $Per_Page = 15;   // Per Page
    $Page = $_GET["Page"];
    if(!$_GET["Page"])
    {
        $Page=1;
    }
                    
    $Prev_Page = $Page-1;
    $Next_Page = $Page+1;
    $Page_Start = (($Per_Page*$Page)-$Per_Page);
    if($Num_Rows<=$Per_Page)
    {
        $Num_Pages =1;
    }
    else if(($Num_Rows % $Per_Page)==0)
    {
        $Num_Pages =($Num_Rows/$Per_Page) ;
    }
    else
    {
        $Num_Pages =($Num_Rows/$Per_Page)+1;
        $Num_Pages = (int)$Num_Pages;
    }
                    
    $strSQL .=" order  by tgl_order DESC LIMIT $Page_Start , $Per_Page";
    $objQuery  = mysql_query($strSQL);
	$intRows = 0;
	while($row=mysql_fetch_array($objQuery)){
?>
  <tr>
    <td><?php echo $no=$no+1;?></td>
    <td><?php echo $row['no_trans'];?></td>
    <td><?php echo $row['tgl_order'];?></td>
    <td><?php echo $row['status'];?></td>
    <td><a href="?page=detail_history&no=<?php echo $row['no_trans'];?>" class="ahref">Lihat</a></td>
  </tr>
  <?php } ?>
  <tr>
    <td colspan="5" align="center">
    <strong>
      Total <?= $Num_Rows;?> Record : <?=$Num_Pages;?> Page :
      <?
      if($Prev_Page)
      {
           echo " <a href='$_SERVER[SCRIPT_NAME]?page=history&Page=$Prev_Page&idk=$ID'><<=Sebelumnya</a> ";
      }
                        
      for($i=1; $i<=$Num_Pages; $i++){
      	if($i != $Page)
        {
             echo "<a href='$_SERVER[SCRIPT_NAME]?page=history&Page=$i&idk=$ID'>$i</a>&nbsp;";
        }
        else
        {
             echo "<b> $i </b>";
        }
      }
      if($Page!=$Num_Pages)
      {
           echo " <a href ='$_SERVER[SCRIPT_NAME]?page=history&Page=$Next_Page&idk=$ID'>Selanjutnya=>></a> ";
      }
?>
      </strong>
    </td>
  </tr>
</table>
</div>
</body>
</html>