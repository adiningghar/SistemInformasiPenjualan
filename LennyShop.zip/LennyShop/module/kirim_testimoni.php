<?php
$nm=$_POST['nm'];
$tes=$_POST['testimoni'];

if($nm=="" or $tes=="")
{
	?>
    <script>
	alert("Gagal Dikirim, Komentar Belum Diisi!");
	document.location='?page=testimoni';
	</script>
    <?php
}
else
{
	$simpan=mysql_query("insert into testimoni values ('',NOW(),'$nm','$tes')");
	if($simpan)
	{
		?>
        <script>
		alert("Komentar Berhasil Dikirim");
		document.location='?page=testimoni';
		</script>
    	<?php
	}
	else
	{
		?>
        <script>
		alert("Gagal Dikirim, Error Query!");
		document.location='?page=testimoni';
		</script>
    	<?php
	}	
}
?>