<?php
include "../koneksi/koneksi.php";
include "../cek_session.php";
include "../library/bar128.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Struk Pemesanan</title>
</head>
<style>
.tabel2, .tabel2 td, .tabel2 th{
	border-collapse:collapse;
	border:solid 1px #999;
}
</style>

<body>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<table width="70%" border="0" align="center" style="border:solid 1px #EEE;">
  <tr>
    <td background="images/detail.jpg" style="color:#FFF;"><h2 style="margin: 0; padding: 0; font-family: Harrington;">Struk Pemesanan</h2></td>
  </tr>
</table>
<?php
$no_trans=$_GET['no'];
$qPesan=mysql_query("select * from pesanan where no_trans='$no_trans'");
$rPesan=mysql_fetch_array($qPesan);
$email=$rPesan['email'];

$pmsn=mysql_query("select * from member where email='$email'");
$dtPmsn=mysql_fetch_array($pmsn);
?>
<table width="70%" border="0" align="center">
  <tr>
    <td><strong>Nomor Transaksi</strong></td>
    <td><?php echo $rPesan['no_trans'];?></td>
  </tr>
  <tr>
    <td width="22%"><strong>Tgl/waktu</strong></td>
    <td width="46%"><?php echo $rPesan['tgl_order'];?>/<?php echo $rPesan['jam_order'];?></td>
  </tr>
  <tr>
    <td><strong>Nama Pemesan</strong></td>
    <td><?php echo $dtPmsn['nama'];?></td>
  </tr>
  <tr>
    <td><strong>Alamat Pengiriman</strong></td>
    <td valign="top"><?php echo $rPesan['alamat_pengiriman'];?></td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
  </table>
  <table width="70%" border="0" align="center" class="tabel2">
  <tr>
    <td width="6%"><strong>No.</strong></td>
    <td width="24%"><strong>Nama Produk</strong></td>
    <td width="21%"><strong>Harga Produk</strong></td>
    <td width="19%"><strong>Jumlah Beli</strong></td>
    <td width="30%"><strong>Subtotal</strong></td>
    </tr>
  <?php
  $qDP=mysql_query("select * from detail_pesanan where no_trans='$no_trans'");
  while($rDP=mysql_fetch_array($qDP)){
	  $idp=$rDP['id_produk'];
	  $qBrg=mysql_query("select * from produk where id_produk='$idp'");
	  $dBrg=mysql_fetch_array($qBrg);
	  $sub=$rDP['harga_produk']*$rDP['jumbel'];
  ?>
  <tr>
    <td><?php 
	  		error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
	echo $no=$no+1;?></td>
    <td><?php echo $dBrg['nama_produk'];?></td>
    <td>Rp. <?php echo $rDP['harga_produk'];?>,-</td>
    <td><?php echo $rDP['jumbel'];?></td>
    <td>Rp. <?php echo $sub;?>,-</td>
    </tr>
  <?php } ?>
  <tr>
    <td colspan="4" align="center"><strong>Ongkos Kirim</strong></td>
    <td>Rp. <?php echo $rPesan['ongkir'];?>,-</td>
    </tr>
  <tr>
    <td colspan="4" align="center"><strong>Total Bayar</strong></td>
    <td>Rp. <?php echo $tot=$rPesan['total']+$rPesan['ongkir'];?>,-</td>
    </tr>
  <tr>
    <td colspan="5"><strong>NB : Cetak struk ini dan segera lakukan transfer sesuai dengan total bayar yang tertera.</strong></td>
  </tr>
</table>
<p>&nbsp;?></p>
<p align="center"><?php echo bar128(stripslashes($rPesan['no_trans'])); ?></p>
</body>
</html>