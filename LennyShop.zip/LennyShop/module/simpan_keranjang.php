<?php
include"cek_session.php";
session_start();
if(!isset($_SESSION['transaksi'])){
	$querycount="SELECT MAX(no_trans) AS Lastno_trans FROM pesanan"; 
	$result=mysql_query($querycount) or die(mysql_error()); 
	$row=mysql_fetch_array($result); 
	$daftar=$row['Lastno_trans']; 
 
	$noUrut = (int) substr($daftar, 8, 5);
	$noUrut++;

	$notrans = date('ymd').'-'. sprintf("%05s", $noUrut);
    $_SESSION['transaksi'] = $notrans;
}

$idtransaksi = $_SESSION['transaksi'];
$ID =$_GET['id'];
if(!isset($ID)){
    die("tidak ada transaksi");
}

$user=$_SESSION['idmember'];

$cekBarang=mysql_query("select * from keranjang where sha1(id_produk)='$ID'");
$barangAda=mysql_num_rows($cekBarang);

$sqlbrg=mysql_query("select * from produk where sha1(id_produk)='$ID'");
$querybrg=mysql_fetch_array($sqlbrg);
$idB=$querybrg['id_produk'];
if($barangAda)
{	
	$queryBarang=mysql_fetch_array($cekBarang);
	$jumbel=$queryBarang['jumbel']+1;
	$jumStok=$querybrg['stok'];
	if($jumStok<$jumbel)
	{
		?>
        <script>
		alert("Stok Kurang");
		document.location='beranda_member.php?page=keranjang_belanja';
		</script>
        <?php
	}
	else
	{
	$updateJumbel=mysql_query("update keranjang set jumbel='$jumbel' where sha1(id_produk)='$ID' and email='$user'");
	if($updateJumbel){
	echo'<script>';
	echo'window.location="beranda_member.php?page=keranjang_belanja"';
	echo'</script> ';
	}else{
    echo "error";
	}
	}
}
else
{
$waktu= date("H:i:s");
$simpan = mysql_query("insert into keranjang values('','$idtransaksi','$idB','1',NOW(),'$waktu','$user')");
if($simpan){
	echo'<script>';
	echo'window.location="beranda_member.php?page=keranjang_belanja"';
	echo'</script> ';
}else{
    echo "error";
}
}
?>