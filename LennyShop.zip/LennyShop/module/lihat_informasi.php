<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<div id="content-2-bawah">
<?php
$idi=$_GET['id'];
$sqlI=mysql_query("select * from informasi where sha1(id_informasi)='$idi'");
$dtInf=mysql_fetch_array($sqlI);
?>
<table width="98%" align="center">
  <tr >
    <td background="images/detail.jpg" class="tdat" style="color:#FFF; font-family: Harrington;"><h2><?php echo $dtInf['judul'];?></h2></td>
  </tr>
</table>
<table width="98%" border="0" align="center">
  <tr>
    <td><?php echo $dtInf['isi'];?></td>
  </tr>
</table>
</div>
</body>
</html>