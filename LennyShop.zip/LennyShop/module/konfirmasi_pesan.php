<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<script type="text/javascript">
// validates that the field value string has one or more characters in it
function isNotEmpty(elem) {
  var str = elem.value;
    var re = /.+/;
    if(!str.match(re)) {
        alert("Tesk Box Harap di isi.");
        setTimeout("focusElement('" + elem.form.name + "', '" + elem.name + "')", 0);
        return false;
    } else {
        return true;
    }
}
//validates that the entry is a positive or negative number
function isNumber(elem) {
  var str = elem.value;
    var re = /^[-]?\d*\.?\d*$/;
    str = str.toString();
    if (!str.match(re)) {
        alert("Enter only numbers into the field.");
        setTimeout("focusElement('" + elem.form.name + "', '" + elem.name + "')", 0);
        return false;
    }
    return true;
}
// validates that the entry is 16 characters long
function isLen16(elem) {
  var str = elem.value;
    var re = /\b.{16}\b/;
    if (!str.match(re)) {
        alert("Entry does not contain the required 16 characters.");
        setTimeout("focusElement('" + elem.form.name + "', '" + elem.name + "')", 0);
        return false;
    } else {
        return true;
    }
}
// validates that the entry is formatted as an e-mail address
function isEMailAddr(elem) {
  var str = elem.value;
    var re = /^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$/;
    if (!str.match(re)) {
        alert("Penulisan alamat e-mail salah.");
        setTimeout("focusElement('" + elem.form.name + "', '" + elem.name + "')", 0);
        return false;
    } else {
        return true;
    }
}
// validate that the user made a selection other than default
function isChosen(select) {
    if (select.selectedIndex == 0) {
        alert("Please make a choice from the list.");
        return false;
    } else {
        return true;
    }
}

// validate that the user has checked one of the radio buttons
function isValidRadio(radio) {
    var valid = false;
    for (var i = 0; i < radio.length; i++) {
        if (radio[i].checked) {
            return true;
        }
    }
    alert("Make a choice from the radio buttons.");
    return false;
}

function focusElement(formName, elemName) {
    var elem = document.forms[formName].elements[elemName];
    elem.focus();
    elem.select();
}

// batch validation router
function validateForm(form) {
    if (isNotEmpty(form.nama)) {
            if (isNotEmpty(form.email)) {
                if (isEMailAddr(form.email)) {
						if (isNotEmpty(form.no_telp)) {
                    					
                            					return true;
										}
                }
            }
    }
    return false;
}
function harusangka(jumlah){
  var karakter = (jumlah.which) ? jumlah.which : event.keyCode
  if (karakter > 31 && (karakter < 48 || karakter > 57))
    return false;

  return true;
}
</script>
</head>

<body>
<div id="content-2-bawah">
<form id="form1" name="form1" method="post" action="?page=aksi_pesan" onsubmit="return validateForm(this)">
  <table width="98%" border="0" align="center" style="border:solid 1px #EEE;">
    <tr>
      <td colspan="3" background="images/detail.jpg" style="color: #FFF; font-family: Harrington;"><h2><strong>Cek Untuk Pengiriman Barang
            <input type="hidden" name="no_pesan" id="no_pesan" />
      </strong></h2></td>
    </tr>
    </table>
    <table width="98%" border="0" align="center">
    <tr>
      <td width="19%"><strong>Nama Pemesan</strong></td>
      <td width="80%"><label for="nama"></label>
        <input name="nama" type="text" id="nama" size="50" onchange="isNotEmpty(this)" value="<?php echo $dtUser['nama'];?>" />
      <input type="hidden" name="id_member" id="id_member" value="<?php echo $dtUser['email'];?>" /></td>
    </tr>
    <tr>
      <td><strong>No. Telp</strong></td>
      <td><label for="no_telp"></label>
      <input name="no_telp" type="text" id="no_telp" size="50" onchange="isNotEmpty(this)" onkeypress="return harusangka(event)" value="<?php echo $dtUser['no_telp'];?>" /></td>
    </tr>
    <tr>
      <td><strong>Email</strong></td>
      <td><label for="email"></label>
      <input name="email" type="text" id="email" size="50" onchange="if (isNotEmpty(this)) {isEMailAddr(this)}" value="<?php echo $dtUser['email'];?>" /></td>
    </tr>
    <tr>
      <td valign="top"><strong>Alamat Pengiriman</strong></td>
      <td><label for="alamat"></label>
      <textarea name="alamat" id="alamat" cols="60" rows="7" placeholder="Masukkan Alamat Pengiriman Barang" required="required"></textarea></td>
    </tr>
    <tr>
      <td valign="top"><strong>Kota</strong></td>
      <td><label for="kota"></label>
        <select name="kota" id="kota">
          <?php
		  $sqlOngkir=mysql_query("select * from ongkir order by kota asc");
		  while($rowOngkir=mysql_fetch_array($sqlOngkir)){
		  ?>
          <option value="<?php echo $rowOngkir['id_ongkir'];?>"><?php echo $rowOngkir['kota'];?></option>
          <?php } ?>
      </select></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><input type="submit" name="button" id="bttn" value="  OK  " /></td>
    </tr>
  </table>
</form>
</div>
</body>
</html>