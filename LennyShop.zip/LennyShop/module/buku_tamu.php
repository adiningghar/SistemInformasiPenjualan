<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
#content-2-bawah #form1 table tr td {
	color: #333333;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 14px;
	text-height: 100;
}
</style>
</head>

<body>
<div id="content-2-bawah">
<form id="form1" name="form1" method="post" action="?page=kirim_bukutamu">
  <table width="100%" border="0" align="center" style="border:solid 1px #EEE;">
    <tr>
      <td colspan="2" background="images/detail.jpg" style="color: #FFF; font-family: Harrington;"><h2>&nbsp;Silahkan Isi Buku Tamu</h2></td>
    </tr>
    </table>
   <table width="100%" border="0" align="center">  
    <tr>
      <td width="21%">&nbsp;</td>
      <td width="79%">&nbsp;</td>
    </tr>
    <tr valign="top">
      <td>Nama Pengunjung</td>
      <td><label for="nama"></label>
      <input name="nama" type="text" id="nama" size="40" maxlength="50" placeholder="" required="required" /></td>
    </tr>
    <tr valign="top">
      <td>Email Pengunjung</td>
      <td><label for="email"></label>
      <input name="email" type="text" id="email" size="40" maxlength="50" placeholder="" required="required" onchange="isEMailAddr(this)" /></td>
    </tr>
    <tr valign="top">
      <td>Pesan</td>
      <td><label for="pesan"></label>
      <textarea name="pesan" id="pesan" cols="50" rows="6" placeholder="" required="required"></textarea></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><input type="submit" name="Submit" id="bttn" value="Kirim" />
      <input type="reset" name="button2" id="bttn" value="  Batal  " /></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <?php
	$query=mysql_query("select count(*) as jumData from buku_tamu where status_tampil='Yes'");
	$dt=mysql_fetch_array($query);
	$jumlah=$dt['jumData']; 
	?>
    <tr>
      <td colspan="2">Pesan Pengunjung (<?php echo $jumlah;?>)</td>
    </tr>
    <?php
	$dataPerPage = 15;
	if(isset($_GET['Hal']))
	{
		$noPage = $_GET['Hal'];
	} 
	else $noPage = 1;
	$offset = ($noPage - 1) * $dataPerPage;
	$q = "SELECT * FROM buku_tamu where status_tampil='Yes' order by tanggal_kirim desc, tanggal_kirim desc limit $offset, $dataPerPage";
	$result = mysql_query($q) or die('Error');
	$i = 1;
	while($row=mysql_fetch_array($result)){
	?>
    <tr>
      <td colspan="2">Name : <?php echo $row['nama'];?>, <?php echo $row['tanggal_kirim'];?><br />Pesan : "<?php echo $row['pesan'];?>"</td>
    </tr>
    <tr>
      <td colspan="2">&nbsp;</td>
    </tr>
    <?php } ?>
    <tr>
      <td colspan="2">Page 
      	<?php
			$jumPage = ceil($jumlah/$dataPerPage);
			if ($noPage > 1);
				for($hal = 1; $hal <= $jumPage; $hal++)
				{
				if ((($hal >= $noPage - 3) && ($hal <= $noPage + 3)) || ($hal == 1) || ($hal == $jumPage)) 
				{   
				if (($showPage == 1) && ($hal != 2))  echo "..."; 
				if (($showPage != ($jumPage - 1)) && ($hal == $jumPage))  echo "...";
				if ($hal == $noPage) echo " <b>".$hal."</b> ";
			else echo " <a class='ahref' href='".$_SERVER['PHP_SELF']."?page=buku_tamu&Hal=".$hal."'>".$hal."</a> ";
				$showPage = $hal;          
				}
			}
			if ($noPage < $jumPage);
									
		?>
      </td>
    </tr>
  </table>
</form>
</div>
</body>
</html>