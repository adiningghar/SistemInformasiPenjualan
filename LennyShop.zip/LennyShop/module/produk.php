<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>                            
<script>
			$(document).ready(function(){
				//Examples of how to assign the Colorbox event to elements
				$(".group1").colorbox({rel:'group1'});
				$(".group2").colorbox({rel:'group2', transition:"fade"});
				$(".group3").colorbox({rel:'group3', transition:"none", width:"75%", height:"75%"});
				$(".group4").colorbox({rel:'group4', slideshow:true});
				$(".ajax").colorbox();
				$(".youtube").colorbox({iframe:true, innerWidth:640, innerHeight:390});
				$(".vimeo").colorbox({iframe:true, innerWidth:500, innerHeight:409});
				$(".iframe").colorbox({iframe:true, width:"80%", height:"80%"});
				$(".inline").colorbox({inline:true, width:"50%"});
				$(".callbacks").colorbox({
					onOpen:function(){ alert('onOpen: colorbox is about to open'); },
					onLoad:function(){ alert('onLoad: colorbox has started to load the targeted content'); },
					onComplete:function(){ alert('onComplete: colorbox has displayed the loaded content'); },
					onCleanup:function(){ alert('onCleanup: colorbox has begun the close process'); },
					onClosed:function(){ alert('onClosed: colorbox has completely closed'); }
				});

				$('.non-retina').colorbox({rel:'group5', transition:'none'})
				$('.retina').colorbox({rel:'group5', transition:'none', retinaImage:true, retinaUrl:true});
				
				//Example of preserving a JavaScript event for inline calls.
				$("#click").click(function(){ 
					$('#click').css({"background-color":"#f00", "color":"#fff", "cursor":"inherit"}).text("Open this window again and this message will still be here.");
					return false;
				});
			});
		</script>
</head>

<body>
<div id="content-2-bawah">
        <?php
		$id=$_GET['idk'];
				
		if($id!="")
		{
		$strSQL = "SELECT * FROM produk where sha1(id_kategori)='$id'";
		$qK=mysql_query("select * from kategori_produk where sha1(id_kategori)='$id'");
		$dK=mysql_fetch_array($qK);
		$judul="Kategori : $dK[nama_kategori]";
		}
		else
		{
		$strSQL = "SELECT * FROM produk";
		$judul="Semua Kategori";
		}
		
                            $objQuery = mysql_query($strSQL);
                            $Num_Rows = mysql_num_rows($objQuery);
                    
                            $Per_Page = 12;   // Per Page
                    
                            $Page = $_GET["Page"];
                            if(!$_GET["Page"])
                            {
                                $Page=1;
                            }
                    
                            $Prev_Page = $Page-1;
                            $Next_Page = $Page+1;
                    
                            $Page_Start = (($Per_Page*$Page)-$Per_Page);
                            if($Num_Rows<=$Per_Page)
                            {
                                $Num_Pages =1;
                            }
                            else if(($Num_Rows % $Per_Page)==0)
                            {
                                $Num_Pages =($Num_Rows/$Per_Page) ;
                            }
                            else
                            {
                                $Num_Pages =($Num_Rows/$Per_Page)+1;
                                $Num_Pages = (int)$Num_Pages;
                            }
                    
                            $strSQL .=" order  by nama_produk ASC LIMIT $Page_Start , $Per_Page";
                            $objQuery  = mysql_query($strSQL);
                    		?>
                    		<table width="100%" align="center" border="0" style="border:solid 1px #EEE;">
                            <tr>
                            <td background="images/detail.jpg" style="color:#FFF; font-family: Harrington;"><h2 style="margin:0; padding:0;">&nbsp;<?=$judul;?></h2></td>
                            </tr>
                            </table>
                            
                            <table  cellspacing="10" cellpadding="10" align="center" style="font-size:12px; color:#904A95; font-family: Arial, Helvetica, sans-serif;">
                            <tr>
								<?
                                $intRows = 0;
                                while($objResult = mysql_fetch_array($objQuery))
                                {
                                    echo "<td  valign='top'>"; 
                                    $intRows++;
                            	?>
                                    <table style="border:solid 1px #EEE; -webkit-border-radius:5px;-moz-border-radius:5px;  	border-radius:5px;">
                                        <tr>
                                        	<td align="center" colspan="2"><a class="group3" href="?page=detail_produk&id=<?=sha1($objResult["id_produk"]);?>" title="<?=$objResult["nama_produk"];?>"><img src="admin/produk/<?=$objResult["gambar"];?>" width="120" height="120" style="-webkit-border-radius: 10px; -moz-border-radius: 10px; border-radius: 10px; padding:5px"></a></td>
                                        </tr>
                                        <?php  
										if($objResult['stok']<=0)
										$ket="<strong><font color='#FF0000'>SOLD OUT!</font></strong>";
										else
										$ket="<strong><font color='#0000FF'>READY STOCK!</font></strong>";
										$IDB=sha1($objResult['id_produk']);
										if(!isset($_SESSION['member']) || ($_SESSION['member']!=md5($_SESSION['idmember'])) )
										{
											if($objResult['stok']<=0)
											{
												$almt="#";
											}
											else
											{
												$confirm="
												alert('Untuk Melakukan Transaksi Anda Harus Login Sebagai Member');
												return confirm('Belum Menjadi Member? Silahkan Daftar Terlebih Dahulu!');";
												$almt="?page=daftar";
											}
										}
										else
										{
											if($objResult['stok']<=0)
											{
												$almt="#";
											}
											else
											{
												$almt="?page=simpan_keranjang&id=$IDB";
											}
										}
										?>
                                                                                <tr>
                                        	<td align="center"><strong><?=$objResult["nama_produk"];?></strong></td>
                                        </tr>
                                        <tr>
                                        	<td align="center">Rp. <?=$objResult["harga_produk"];?>,-</td>
                                        </tr>
                                        <tr>
                                        	<td align="center"><strong><a href="?page=detail_produk&id=<?=sha1($objResult["id_produk"]);?>" class="ahref"><img src="images/icon_detail_data.png" width="15" height="10" />Detail</a> | <a href="<?php echo $almt;?>" class="ahref" onclick="<?php echo $confirm;?>"><img src="images/Logo Keranjang Belanja 1.jpg" width="15" height="10" />Beli</a></strong></td>
                                        </tr>
                                   </table>
                            	<?
                                    echo"</td>";
                                    if(($intRows)%4==0)
                                    {
                                        echo"</tr>";
                                    }
                                }
                           		?>
                        		</tr>
                                <tr>
                                <td colspan="6" align="center" style="font-size:12px;">
                                Total <?= $Num_Rows;?> Record : <?=$Num_Pages;?> Page :
                                <?
                                if($Prev_Page)
                                {
                                    echo " <a href='$_SERVER[SCRIPT_NAME]?page=produk&idk=$id&Page=$Prev_Page&id=$ID' class='ah1'><< Back</a> ";
                                }
                        
                                for($i=1; $i<=$Num_Pages; $i++){
                                    if($i != $Page)
                                    {
                                        echo "<a href='$_SERVER[SCRIPT_NAME]?page=produk&idk=$id&Page=$i&id=$ID' class='ah1'>$i</a>&nbsp;";
                                    }
                                    else
                                    {
                                        echo "<b> $i </b>";
                                    }
                                }
                                if($Page!=$Num_Pages)
                                {
                                    echo " <a href ='$_SERVER[SCRIPT_NAME]?page=produk&idk=$id&Page=$Next_Page&id=$ID' class='ah1'>Next>></a> ";
                                }
                                ?>
                     </td>
                </tr>
                                </table>
                       </div>     
</body>
</html>