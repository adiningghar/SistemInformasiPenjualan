<?php
if($_POST)
{
	$cek=mysql_query("select * from pesanan where no_trans='".$_POST['no_trans']."'");
	$ada=mysql_num_rows($cek);
	if($ada)
	{
	$simpan=mysql_query("insert into konfirmasi_bayar values('',NOW(),'".$_POST['no_trans']."','".$_POST['norek']."','".$_POST['an']."','".$_POST['b_tujuan']."','".$_POST['jml']."')");
	if($simpan)
	{
		?>
        <script>
		alert('Pengiriman Konfirmasi Pembayaran Berhasil, Kami Akan Segera Memproses Pesanan Anda.');
		document.location='?page=konfirmasi_bayar';
		</script>
        <?php
	}
	else
	{
		?>
        <script>
		alert('Pengiriman Konfirmasi Pembayaran GAGAL');
		document.location='?page=konfirmasi_bayar';
		</script>
        <?php
	}
	}
	else
	{
		?>
        <script>
		alert('Pengiriman Konfirmasi Pembayaran GAGAL, Nomor Transaksi yang Anda Masukkan Tidak Ditemukan. Pastikan Nomor Transaksi yang Anda Masukkan Benar.');
		document.location='?page=konfirmasi_bayar';
		</script>
        <?php
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
#form1 table tr td {
	color: #333333;
	font-size: 12px;
	font-family: Arial, Helvetica, sans-serif;
}
#form1 table tr th {
	color: #333333;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
}
</style>
</head>

<body>
<form id="form1" name="form1" method="post" action="">  
  <table width="100%" border="0" align="center" style="border:solid 1px #EEE;">
    <tr>
      <td background="images/detail.jpg" style="color: #FFF; font-family: Harrington;"><h2>&nbsp;Konfirmasi Pembayaran</h2></td>
    </tr>
  </table>
  <table width="100%" border="0" align="left" cellspacing="10">
    <tr>
    <th width="25%">Nomor Transaksi</th>
    <td width="75%"><strong>
      <input name="no_trans" type="text" required placeholder="" id="no_trans" size="30" maxlength="12" onKeyPress="return harusangka(event)" />
    </strong></td>
    </tr>
  <tr>
    <th scope="">Nomor Rekening</th>
    <td><label for="norek"></label>
      <input name="norek" type="text" id="norek" size="30" maxlength="30" onKeyPress="return harusangka(event)" placeholder="" required />        <label for="b_tujuan"></label></td>
    </tr>
  <tr>
    <th scope="row">Atas Nama Rekening</th>
    <td><label for="an"></label>
      <input name="an" type="text" id="an" size="30" maxlength="30" placeholder="" required /></td>
    </tr>
  <tr>
    <th scope="row">Transfer Ke Rekening</th>
    <td><select name="b_tujuan" id="b_tujuan">
        <option value="">--- Silahkan Pilih ---</option>
        <option value="BCA 9999999999 (A.n. xxx)">BCA 9999999999 (A.n. xxx)</option>
        <option value="Mandiri 9999999999 (A.n. xxx)">Mandiri 9999999999 (A.n. xxx)</option>
        <option value="BRI 9999999999 (A.n. xxx)">BRI 9999999999 (A.n. xxx)</option>
      </select></td>
    </tr>
  <tr>
    <th scope="row">Jumlah Transfer</th>
    <td>Rp. 
      <input type="text" name="jml" id="jml" placeholder="" required onKeyPress="return harusangka(event)" />
      ,-</td>
    </tr>
  <tr>
    <th scope="row">&nbsp;</th>
    <td><input type="submit" name="Submit" id="bttn" value="Kirim" />
      <input type="reset" name="Reset" id="bttn" value="Batal" /></td>
  </tr>
  </table>
</form>
</body>
</html>