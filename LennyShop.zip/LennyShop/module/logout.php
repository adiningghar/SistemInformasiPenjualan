<?php 
session_start();
	unset($_SESSION['member']);
	?>
	<script language="javascript">
	alert("Anda Telah Logout");
	document.location="index.php";
	</script> 