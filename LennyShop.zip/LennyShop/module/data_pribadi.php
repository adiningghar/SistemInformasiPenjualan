<?php
if($_POST)
{
	$update=mysql_query("update member set nama='".$_POST['nama']."', alamat='".$_POST['alamat']."', no_telp='".$_POST['telp']."' where email='".$_POST['email']."'");
	if($update)
	{
		?>
        <script>
		alert("Update Profil Berhasil");
		document.location='?page=data_pribadi';
		</script>
        <?php
	}
	else
	{
		?>
        <script>
		alert("Update Profil GAGAL");
		document.location='?page=data_pribadi';
		</script>
        <?php
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
#content-2-bawah #form1 table tr td strong {
	color: #636363;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 14px;
}
</style>
</head>

<body>
<div id="content-2-bawah">
<form id="form1" name="form1" method="post" action="">
  <table width="100%" border="0" align="center" style="border:solid 1px #EEE;">
    <tr>
      <td background="images/detail.jpg" style="color: #FFF; font-family: Harrington;"><h2>&nbsp;Data Pribadi</h2></td>
    </tr>
  </table>
  <table width="100%" border="0" align="center">
    <tr>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td><strong>Nama</strong></td>
    </tr>
    <tr>
      <td><strong>
      <input name="nama" type="text" required id="nama" value="<?php echo $dtUser['nama'];?>" size="30" maxlength="30" />
      </strong></td>
    </tr>
    <tr>
      <td><strong>Email</strong></td>
    </tr>
    <tr>
      <td><strong>
      <input name="email" type="text" id="email" value="<?php echo $dtUser['email'];?>" size="40" maxlength="50" readonly />
      </strong></td>
    </tr>
    <tr>
      <td><strong>Alamat</strong></td>
    </tr>
    <tr>
      <td><strong>
      <textarea name="alamat" id="alamat" cols="60" rows="8" required><?php echo $dtUser['alamat'];?></textarea>
      </strong></td>
    </tr>
    <tr>
      <td><strong>Nomor Telepon</strong></td>
    </tr>
    <tr>
      <td><strong>
      <input name="telp" type="text" required id="telp" onKeyPress="return harusangka(event)" value="<?php echo $dtUser['no_telp'];?>" size="30" maxlength="12" />
      </strong></td>
    </tr>
    <tr>
      <td><input type="submit" name="Submit" id="bttn" value="  Update  " /></td>
    </tr>
  </table>
</form>
</div>
</body>
</html>